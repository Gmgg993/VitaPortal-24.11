using VitaPortal.Models;

namespace VitaPortal.Services;

/// <summary>Результат операции: успех/неуспех и понятное сообщение.</summary>
public readonly record struct OpResult(bool Ok, string Message)
{
    public static OpResult Success(string message) => new(true, message);
    public static OpResult Fail(string message) => new(false, message);
}

/// <summary>Статистика портала (задача 24).</summary>
public readonly record struct PortalStatistics(
    int Patients, int Doctors, int Departments, int Appointments,
    int Completed, int Cancelled, int PaidPayments, decimal PaidTotal);

/// <summary>
/// Главный управляющий класс: хранит коллекции и выполняет операции системы.
/// Консольный ввод-вывод вынесен в UI/MainMenu.cs.
/// </summary>
public class MedicalPortal
{
    private readonly List<Patient> _patients = new();
    private readonly List<Doctor> _doctors = new();
    private readonly List<Department> _departments = new();
    private readonly List<MedicalService> _services = new();
    private readonly List<Appointment> _appointments = new();
    private readonly List<MedicalTest> _tests = new();
    private readonly List<Prescription> _prescriptions = new();
    private readonly List<Payment> _payments = new();
    private readonly List<SickLeaveRequest> _requests = new();

    private int _patientSeq, _doctorSeq, _departmentSeq, _serviceSeq,
                _appointmentSeq, _testSeq, _prescriptionSeq, _paymentSeq, _requestSeq;

    public IReadOnlyList<Patient> Patients => _patients;
    public IReadOnlyList<Doctor> Doctors => _doctors;
    public IReadOnlyList<Department> Departments => _departments;
    public IReadOnlyList<MedicalService> Services => _services;
    public IReadOnlyList<Appointment> Appointments => _appointments;
    public IReadOnlyList<MedicalTest> Tests => _tests;
    public IReadOnlyList<Prescription> Prescriptions => _prescriptions;
    public IReadOnlyList<Payment> Payments => _payments;
    public IReadOnlyList<SickLeaveRequest> Requests => _requests;

    // ---------- добавление ----------------------------------------------

    public Patient AddPatient(string fullName, DateTime birthDate, string phone, string email, string address = "")
    {
        var p = new Patient(++_patientSeq, fullName, birthDate, phone, email, address);
        _patients.Add(p);
        return p;
    }

    public Doctor AddDoctor(string fullName, DateTime birthDate, string specialization,
                            int experience, int cabinet, decimal salary)
    {
        var d = new Doctor(++_doctorSeq, fullName, birthDate, specialization, experience, cabinet, salary);
        _doctors.Add(d);
        return d;
    }

    public Department AddDepartment(string name, int floor, string phone)
    {
        var d = new Department(++_departmentSeq, name, floor, phone);
        _departments.Add(d);
        return d;
    }

    public MedicalService AddService(string name, string description, decimal price, int minutes)
    {
        var s = new MedicalService(++_serviceSeq, name, description, price, TimeSpan.FromMinutes(minutes));
        _services.Add(s);
        return s;
    }

    // ---------- поиск ---------------------------------------------------

    public Patient? FindPatient(int id) => _patients.FirstOrDefault(p => p.PatientId == id);
    public Doctor? FindDoctor(int id) => _doctors.FirstOrDefault(d => d.DoctorId == id);
    public Department? FindDepartment(int id) => _departments.FirstOrDefault(d => d.DepartmentId == id);
    public MedicalService? FindService(int id) => _services.FirstOrDefault(s => s.ServiceId == id);
    public Appointment? FindAppointment(int id) => _appointments.FirstOrDefault(a => a.AppointmentId == id);
    public MedicalTest? FindTest(int id) => _tests.FirstOrDefault(t => t.TestId == id);
    public Payment? FindPayment(int id) => _payments.FirstOrDefault(p => p.PaymentId == id);
    public SickLeaveRequest? FindRequest(int id) => _requests.FirstOrDefault(r => r.RequestId == id);

    /// <summary>Поиск пациента по идентификатору (задача 23).</summary>
    public Patient? FindPatientById(int id) => FindPatient(id);

    /// <summary>Поиск пациентов по части ФИО без учёта регистра (задача 23).</summary>
    public List<Patient> FindPatientsByName(string text)
    {
        text = (text ?? "").Trim();
        if (text.Length == 0) return new List<Patient>();
        return _patients
            .Where(p => p.FullName.Contains(text, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    /// <summary>Поиск по номеру телефона: сравниваются только цифры, достаточно части номера (задача 23).</summary>
    public List<Patient> FindPatientsByPhone(string phone)
    {
        string digits = Digits(phone);
        if (digits.Length == 0) return new List<Patient>();
        return _patients.Where(p => Digits(p.PhoneNumber).Contains(digits)).ToList();
    }

    private static string Digits(string? s) => new string((s ?? "").Where(char.IsDigit).ToArray());

    // ---------- приёмы --------------------------------------------------

    /// <summary>Записывает пациента к врачу. Проверяет рабочее время и двойную запись (задачи 7, 8).</summary>
    public OpResult BookAppointment(int patientId, int doctorId, DateTime date, TimeSpan time, int? serviceId = null)
    {
        var patient = FindPatient(patientId);
        if (patient == null) return OpResult.Fail($"Пациент с номером {patientId} не найден.");
        var doctor = FindDoctor(doctorId);
        if (doctor == null) return OpResult.Fail($"Врач с номером {doctorId} не найден.");

        MedicalService? service = null;
        if (serviceId != null)
        {
            service = FindService(serviceId.Value);
            if (service == null) return OpResult.Fail($"Услуга с номером {serviceId} не найдена.");
        }

        var slot = date.Date + time;
        if (slot < DateTime.Now)
            return OpResult.Fail("Нельзя записать на прошедшее время.");
        if (!Doctor.IsWorkingTime(slot))
            return OpResult.Fail("Врач не принимает в это время (пн–сб, 09:00–18:00).");

        var appointment = new Appointment(_appointmentSeq + 1, patient, doctor, date, time, service);
        if (!appointment.CreateAppointment())
            return OpResult.Fail(Appointment.DoctorBusyMessage);

        _appointmentSeq++;
        _appointments.Add(appointment);
        return OpResult.Success(
            $"Запись №{appointment.AppointmentId} оформлена: {patient.FullName} → {doctor.FullName}, " +
            $"{appointment.AppointmentDate:dd.MM.yyyy} в {appointment.AppointmentTime:hh\\:mm}.");
    }

    public OpResult CancelAppointment(int appointmentId)
    {
        var a = FindAppointment(appointmentId);
        if (a == null) return OpResult.Fail($"Запись №{appointmentId} не найдена.");
        return a.CancelAppointment()
            ? OpResult.Success($"Запись №{appointmentId} отменена, время врача освобождено.")
            : OpResult.Fail("Эту запись уже нельзя отменить (она завершена или уже отменена).");
    }

    public OpResult ConfirmAppointment(int appointmentId)
    {
        var a = FindAppointment(appointmentId);
        if (a == null) return OpResult.Fail($"Запись №{appointmentId} не найдена.");
        return a.ConfirmAppointment()
            ? OpResult.Success($"Запись №{appointmentId} подтверждена.")
            : OpResult.Fail("Подтвердить можно только запись со статусом «Запланирован».");
    }

    public OpResult CompleteAppointment(int appointmentId)
    {
        var a = FindAppointment(appointmentId);
        if (a == null) return OpResult.Fail($"Запись №{appointmentId} не найдена.");
        return a.CompleteAppointment()
            ? OpResult.Success($"Приём по записи №{appointmentId} завершён.")
            : OpResult.Fail("Завершить можно только подтверждённую запись.");
    }

    /// <summary>Расписание врача: активные записи, по возрастанию времени.</summary>
    public List<Appointment> GetDoctorSchedule(Doctor doctor, DateTime? day = null)
    {
        return doctor.Appointments
            .Where(a => a.Status != AppointmentStatus.Cancelled)
            .Where(a => day == null || a.AppointmentDate == day.Value.Date)
            .OrderBy(a => a.StartsAt)
            .ToList();
    }

    // ---------- анализы, назначения, оплата -----------------------------

    public MedicalTest AddTest(int patientId, string testName, DateTime date, string? result = null)
    {
        var patient = FindPatient(patientId) ?? throw new ArgumentException($"Пациент с номером {patientId} не найден.");
        var test = new MedicalTest(_testSeq + 1, testName, date, patient);
        if (!string.IsNullOrWhiteSpace(result)) test.AddResult(result);
        _testSeq++;
        patient.AddTest(test);
        _tests.Add(test);
        return test;
    }

    public Prescription CreatePrescription(int patientId, int doctorId, string medication, string dosage, int days)
    {
        var patient = FindPatient(patientId) ?? throw new ArgumentException($"Пациент с номером {patientId} не найден.");
        var doctor = FindDoctor(doctorId) ?? throw new ArgumentException($"Врач с номером {doctorId} не найден.");
        var p = new Prescription(_prescriptionSeq + 1, patient, doctor, medication, dosage, days);
        p.CreatePrescription();
        _prescriptionSeq++;
        _prescriptions.Add(p);
        return p;
    }

    /// <summary>Оплата услуги: создаёт платёж на сумму услуги (с учётом количества и скидки) и проводит его.</summary>
    public OpResult PayForService(int patientId, int serviceId, int quantity = 1, decimal discountPercent = 0m)
    {
        var patient = FindPatient(patientId);
        if (patient == null) return OpResult.Fail($"Пациент с номером {patientId} не найден.");
        var service = FindService(serviceId);
        if (service == null) return OpResult.Fail($"Услуга с номером {serviceId} не найдена.");

        decimal amount = service.CalculatePrice(quantity, discountPercent);
        if (amount <= 0) return OpResult.Fail("Услуга бесплатна — оплата не требуется.");

        var payment = new Payment(_paymentSeq + 1, patient, amount, service);
        payment.MakePayment();
        _paymentSeq++;
        _payments.Add(payment);
        return OpResult.Success($"Платёж №{payment.PaymentId} на сумму {UI.ConsoleUi.Money(amount)} принят.");
    }

    public OpResult RefundPayment(int paymentId)
    {
        var p = FindPayment(paymentId);
        if (p == null) return OpResult.Fail($"Платёж №{paymentId} не найден.");
        return p.RefundPayment()
            ? OpResult.Success($"Платёж №{paymentId} возвращён: {UI.ConsoleUi.Money(p.Amount)}.")
            : OpResult.Fail("Вернуть можно только оплаченный платёж.");
    }

    // ---------- заявления на больничный / справки -----------------------

    public SickLeaveRequest AddRequest(int patientId, RequestType type, string reason)
    {
        var patient = FindPatient(patientId) ?? throw new ArgumentException($"Пациент с номером {patientId} не найден.");
        var r = new SickLeaveRequest(_requestSeq + 1, patient, type, reason);
        _requestSeq++;
        _requests.Add(r);
        return r;
    }

    // ---------- статистика ----------------------------------------------

    public PortalStatistics GetStatistics()
    {
        var paid = _payments.Where(p => p.PaymentStatus == PaymentStatus.Paid).ToList();
        return new PortalStatistics(
            Patients: _patients.Count,
            Doctors: _doctors.Count,
            Departments: _departments.Count,
            Appointments: _appointments.Count,
            Completed: _appointments.Count(a => a.Status == AppointmentStatus.Completed),
            Cancelled: _appointments.Count(a => a.Status == AppointmentStatus.Cancelled),
            PaidPayments: paid.Count,
            PaidTotal: paid.Sum(p => p.Amount));
    }
}
