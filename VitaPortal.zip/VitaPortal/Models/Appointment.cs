using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>
/// Запись на приём (задачи 6, 8, 11, 12, 20).
/// Каждая запись ссылается на одного пациента и одного врача.
/// </summary>
public class Appointment : IPayable
{
    public const string DoctorBusyMessage = "Врач уже занят на указанное время!";

    public int AppointmentId { get; }
    public Patient Patient { get; }
    public Doctor Doctor { get; }
    public MedicalService? Service { get; }

    /// <summary>Только дата приёма.</summary>
    public DateTime AppointmentDate { get; }

    /// <summary>Время приёма (чч:мм).</summary>
    public TimeSpan AppointmentTime { get; }

    public AppointmentStatus Status { get; private set; } = AppointmentStatus.Scheduled;

    /// <summary>true, если запись уже зарегистрирована у пациента и врача.</summary>
    public bool IsCreated { get; private set; }

    public DateTime StartsAt => Doctor.Trim(AppointmentDate.Date + AppointmentTime);

    public Appointment(int id, Patient patient, Doctor doctor, DateTime date, TimeSpan time, MedicalService? service = null)
    {
        AppointmentId = id;
        Patient = Guard.NotNull(patient, nameof(patient));
        Doctor = Guard.NotNull(doctor, nameof(doctor));
        Service = service;
        AppointmentDate = date.Date;
        AppointmentTime = time;
    }

    /// <summary>
    /// Регистрирует запись у пациента и врача.
    /// Возвращает false, если время занято (защита от двойной записи, задача 8).
    /// </summary>
    public bool CreateAppointment()
    {
        if (IsCreated) return false;
        if (!Doctor.IsDoctorAvailable(StartsAt)) return false;

        Patient.AddAppointment(this);
        Doctor.AddAppointment(this);
        IsCreated = true;
        return true;
    }

    public bool ConfirmAppointment()
    {
        if (!IsCreated || Status != AppointmentStatus.Scheduled) return false;
        Status = AppointmentStatus.Confirmed;
        return true;
    }

    public bool CompleteAppointment()
    {
        if (Status != AppointmentStatus.Confirmed) return false;
        Status = AppointmentStatus.Completed;
        return true;
    }

    public bool CancelAppointment()
    {
        if (Status is AppointmentStatus.Completed or AppointmentStatus.Cancelled) return false;
        Status = AppointmentStatus.Cancelled;
        return true;
    }

    /// <summary>Сумма к оплате = стоимость выбранной услуги (0, если услуга не выбрана).</summary>
    public decimal CalculatePayment() => Service?.Price ?? 0m;

    public void DisplayAppointment() =>
        ConsoleUi.Card($"Запись №{AppointmentId}",
            ("Пациент", Patient.FullName),
            ("Врач", $"{Doctor.FullName} ({Doctor.Specialization})"),
            ("Кабинет", Doctor.CabinetNumber.ToString()),
            ("Дата и время", $"{AppointmentDate:dd.MM.yyyy} {AppointmentTime:hh\\:mm}"),
            ("Услуга", Service?.ServiceName ?? "консультация"),
            ("Статус", Status.Ru()));
}
