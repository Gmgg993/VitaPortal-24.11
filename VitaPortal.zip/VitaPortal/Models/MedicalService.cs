using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>Медицинская услуга (задача 5).</summary>
public class MedicalService
{
    private string _name = "";
    private decimal _price;
    private TimeSpan _duration;

    public int ServiceId { get; }

    public string ServiceName
    {
        get => _name;
        set => _name = Guard.NotBlank(value, "Название услуги");
    }

    public string Description { get; set; } = "";

    public decimal Price
    {
        get => _price;
        private set => _price = Guard.NotNegative(value, "Стоимость услуги");
    }

    public TimeSpan Duration
    {
        get => _duration;
        set
        {
            if (value <= TimeSpan.Zero)
                throw new ArgumentException("Длительность услуги должна быть больше нуля.");
            _duration = value;
        }
    }

    public MedicalService(int id, string name, string description, decimal price, TimeSpan duration)
    {
        ServiceId = id;
        ServiceName = name;
        Description = description ?? "";
        Price = price;
        Duration = duration;
    }

    /// <summary>Стоимость нескольких единиц услуги с учётом скидки в процентах.</summary>
    public decimal CalculatePrice(int quantity = 1, decimal discountPercent = 0m)
    {
        if (quantity < 1) throw new ArgumentException("Количество должно быть не меньше 1.");
        if (discountPercent < 0 || discountPercent > 100)
            throw new ArgumentException("Скидка должна быть от 0 до 100 процентов.");
        return Math.Round(Price * quantity * (1 - discountPercent / 100m), 2);
    }

    public void UpdatePrice(decimal newPrice) => Price = newPrice;

    public void DisplayService() =>
        ConsoleUi.Card($"Услуга №{ServiceId}",
            ("Название", ServiceName),
            ("Описание", string.IsNullOrWhiteSpace(Description) ? "—" : Description),
            ("Стоимость", ConsoleUi.Money(Price)),
            ("Длительность", $"{(int)Duration.TotalMinutes} мин"));
}
