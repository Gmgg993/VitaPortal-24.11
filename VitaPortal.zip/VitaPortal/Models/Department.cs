using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>
/// Отделение клиники (задача 4).
/// Агрегация с Doctor (задача 13): отделение содержит врачей, но врач существует и без отделения.
/// </summary>
public class Department
{
    private readonly List<Doctor> _doctors = new();
    private string _name = "";
    private string _phone = "";
    private int _floor;

    public int DepartmentId { get; }

    public string DepartmentName
    {
        get => _name;
        set => _name = Guard.NotBlank(value, "Название отделения");
    }

    public int Floor
    {
        get => _floor;
        set => _floor = Guard.InRange(value, -2, 50, "Этаж");
    }

    public string PhoneNumber
    {
        get => _phone;
        set => _phone = Guard.NotBlank(value, "Телефон отделения");
    }

    public Doctor? HeadDoctor { get; private set; }

    public IReadOnlyList<Doctor> Doctors => _doctors;

    public Department(int id, string name, int floor, string phone)
    {
        DepartmentId = id;
        DepartmentName = name;
        Floor = floor;
        PhoneNumber = phone;
    }

    /// <summary>Добавляет врача. Возвращает false, если он уже работает в этом или другом отделении.</summary>
    public bool AddDoctor(Doctor doctor)
    {
        Guard.NotNull(doctor, nameof(doctor));
        if (doctor.Department != null) return false;
        _doctors.Add(doctor);
        doctor.Department = this;
        return true;
    }

    public bool RemoveDoctor(Doctor doctor)
    {
        if (!_doctors.Remove(doctor)) return false;
        doctor.Department = null;
        if (HeadDoctor == doctor) HeadDoctor = null;
        return true;
    }

    public bool SetHeadDoctor(Doctor doctor)
    {
        if (!_doctors.Contains(doctor)) return false;
        HeadDoctor = doctor;
        return true;
    }

    public void DisplayDoctors()
    {
        ConsoleUi.Title($"Врачи отделения «{DepartmentName}»");
        ConsoleUi.Table(
            new[] { "ID", "ФИО", "Специализация", "Каб.", "Роль" },
            _doctors.Select(d => new[]
            {
                d.DoctorId.ToString(), d.FullName, d.Specialization, d.CabinetNumber.ToString(),
                d == HeadDoctor ? "Заведующий" : "Врач"
            }));
    }
}
