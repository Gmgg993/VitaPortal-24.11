namespace VitaPortal.Models;

/// <summary>Статус записи на приём (задача 20).</summary>
public enum AppointmentStatus
{
    Scheduled,
    Confirmed,
    Completed,
    Cancelled
}

public enum PaymentStatus
{
    Pending,
    Paid,
    Refunded
}

public enum RequestType
{
    SickLeave,
    Certificate
}

public enum RequestStatus
{
    New,
    UnderReview,
    NeedDocuments,
    Approved,
    Rejected,
    Completed
}

/// <summary>Русские названия для вывода в консоли.</summary>
public static class EnumText
{
    public static string Ru(this AppointmentStatus s) => s switch
    {
        AppointmentStatus.Scheduled => "Запланирован",
        AppointmentStatus.Confirmed => "Подтверждён",
        AppointmentStatus.Completed => "Завершён",
        AppointmentStatus.Cancelled => "Отменён",
        _ => s.ToString()
    };

    public static string Ru(this PaymentStatus s) => s switch
    {
        PaymentStatus.Pending => "Ожидает оплаты",
        PaymentStatus.Paid => "Оплачен",
        PaymentStatus.Refunded => "Возвращён",
        _ => s.ToString()
    };

    public static string Ru(this RequestType t) => t switch
    {
        RequestType.SickLeave => "Больничный",
        RequestType.Certificate => "Справка",
        _ => t.ToString()
    };

    public static string Ru(this RequestStatus s) => s switch
    {
        RequestStatus.New => "Новое",
        RequestStatus.UnderReview => "На рассмотрении",
        RequestStatus.NeedDocuments => "Нужны документы",
        RequestStatus.Approved => "Одобрено",
        RequestStatus.Rejected => "Отклонено",
        RequestStatus.Completed => "Завершено",
        _ => s.ToString()
    };
}
