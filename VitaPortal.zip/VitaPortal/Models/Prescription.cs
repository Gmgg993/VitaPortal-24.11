using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>Медицинское назначение (задача 22).</summary>
public class Prescription
{
    public int PrescriptionId { get; }
    public Patient Patient { get; }
    public Doctor Doctor { get; }
    public string MedicationName { get; private set; } = "";
    public string Dosage { get; private set; } = "";

    /// <summary>Длительность курса в днях.</summary>
    public int Duration { get; private set; }

    public DateTime IssuedDate { get; private set; }
    public bool IsCreated { get; private set; }

    public Prescription(int id, Patient patient, Doctor doctor, string medicationName, string dosage, int durationDays)
    {
        PrescriptionId = id;
        Patient = Guard.NotNull(patient, nameof(patient));
        Doctor = Guard.NotNull(doctor, nameof(doctor));
        Apply(medicationName, dosage, durationDays);
    }

    private void Apply(string medicationName, string dosage, int durationDays)
    {
        string m = Guard.NotBlank(medicationName, "Препарат");
        string d = Guard.NotBlank(dosage, "Дозировка");
        int days = Guard.InRange(durationDays, 1, 365, "Длительность курса (дни)");
        MedicationName = m;
        Dosage = d;
        Duration = days;
    }

    /// <summary>Оформляет назначение: добавляет его в карточку пациента.</summary>
    public bool CreatePrescription()
    {
        if (IsCreated) return false;
        Patient.AddPrescription(this);
        IssuedDate = DateTime.Today;
        IsCreated = true;
        return true;
    }

    public void UpdatePrescription(string medicationName, string dosage, int durationDays) =>
        Apply(medicationName, dosage, durationDays);

    public void DisplayPrescription() =>
        ConsoleUi.Card($"Назначение №{PrescriptionId}",
            ("Пациент", Patient.FullName),
            ("Врач", Doctor.FullName),
            ("Препарат", MedicationName),
            ("Дозировка", Dosage),
            ("Курс", $"{Duration} дн."),
            ("Выдано", IsCreated ? IssuedDate.ToString("dd.MM.yyyy") : "не оформлено"));
}
