using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>
/// Заявление на больничный или справку. Эта функциональность была в прежнем проекте
/// («МедПортал») и сохранена: те же статусы и те же бизнес-правила.
/// </summary>
public class SickLeaveRequest
{
    private static readonly Dictionary<RequestStatus, RequestStatus[]> Transitions = new()
    {
        [RequestStatus.New] = new[] { RequestStatus.UnderReview, RequestStatus.NeedDocuments, RequestStatus.Rejected },
        [RequestStatus.UnderReview] = new[] { RequestStatus.NeedDocuments, RequestStatus.Approved, RequestStatus.Rejected },
        [RequestStatus.NeedDocuments] = new[] { RequestStatus.UnderReview, RequestStatus.Rejected },
        [RequestStatus.Approved] = new[] { RequestStatus.Completed },
        [RequestStatus.Rejected] = Array.Empty<RequestStatus>(),
        [RequestStatus.Completed] = Array.Empty<RequestStatus>()
    };

    public int RequestId { get; }
    public Patient Patient { get; }
    public RequestType Type { get; }
    public string Reason { get; }
    public DateTime CreatedAt { get; }
    public RequestStatus Status { get; private set; } = RequestStatus.New;
    public Doctor? AssignedDoctor { get; private set; }
    public bool? DoctorRecommendsApproval { get; private set; }
    public string DoctorComment { get; private set; } = "";
    public string? RejectReason { get; private set; }
    public string? DocumentNumber { get; private set; }

    /// <summary>Пациент может только подать заявление: статус всегда «Новое».</summary>
    public SickLeaveRequest(int id, Patient patient, RequestType type, string reason)
    {
        RequestId = id;
        Patient = Guard.NotNull(patient, nameof(patient));
        Type = type;
        Reason = Guard.NotBlank(reason, "Причина обращения");
        CreatedAt = DateTime.Now;
    }

    public bool CanGoTo(RequestStatus next) => Transitions[Status].Contains(next);

    public void AssignDoctor(Doctor doctor)
    {
        AssignedDoctor = Guard.NotNull(doctor, nameof(doctor));
        DoctorRecommendsApproval = null;
        DoctorComment = "";
    }

    /// <summary>Врач видит только назначенные ему заявления и даёт рекомендацию; решение принимает администратор.</summary>
    public void SetDoctorRecommendation(Doctor doctor, bool recommendApproval, string comment)
    {
        if (AssignedDoctor == null || AssignedDoctor != doctor)
            throw new InvalidOperationException("Рекомендацию может дать только назначенный врач.");
        DoctorRecommendsApproval = recommendApproval;
        DoctorComment = Guard.NotBlank(comment, "Заключение врача");
    }

    public void ChangeStatus(RequestStatus next, string? reason = null, string? documentNumber = null)
    {
        if (!CanGoTo(next))
            throw new InvalidOperationException($"Нельзя перейти из «{Status.Ru()}» в «{next.Ru()}».");

        switch (next)
        {
            case RequestStatus.Approved:
                if (AssignedDoctor == null || DoctorRecommendsApproval != true)
                    throw new InvalidOperationException(
                        "Одобрить можно только при назначенном враче и его рекомендации «одобрить».");
                break;
            case RequestStatus.Rejected:
                RejectReason = Guard.NotBlank(reason, "Причина отказа");
                break;
            case RequestStatus.Completed:
                DocumentNumber = Guard.NotBlank(documentNumber, "Номер готового документа");
                break;
        }

        Status = next;
    }

    public void Display() =>
        ConsoleUi.Card($"Заявление №{RequestId}",
            ("Пациент", Patient.FullName),
            ("Тип", Type.Ru()),
            ("Причина", ConsoleUi.Cut(Reason, 50)),
            ("Подано", CreatedAt.ToString("dd.MM.yyyy HH:mm")),
            ("Статус", Status.Ru()),
            ("Врач", AssignedDoctor?.FullName ?? "не назначен"),
            ("Рекомендация", DoctorRecommendsApproval switch
            {
                true => "одобрить",
                false => "не одобрять",
                _ => "—"
            }),
            ("Документ", DocumentNumber ?? "—"));
}
