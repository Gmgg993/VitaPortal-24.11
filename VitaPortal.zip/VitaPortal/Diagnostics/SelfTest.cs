using VitaPortal.Models;
using VitaPortal.Services;

namespace VitaPortal.Diagnostics;

/// <summary>
/// Автоматическая проверка основных сценариев (без внешних библиотек).
/// Запуск: dotnet run -- --selftest
/// </summary>
public static class SelfTest
{
    private static int _passed;
    private static int _failed;

    public static int Run()
    {
        Console.WriteLine("VitaPortal — самопроверка сценариев");
        Console.WriteLine(new string('-', 60));

        Check("Person абстрактный, Patient и Doctor — его наследники",
            () => typeof(Person).IsAbstract && typeof(Patient).BaseType == typeof(Person) && typeof(Doctor).BaseType == typeof(Person));

        Check("Возраст: дата рождения в будущем запрещена",
            () => Throws<ArgumentException>(() => new Patient(1, "Тест Тестов", DateTime.Today.AddDays(1), "1", "a@b.kz")));

        Check("Возраст считается по полным годам",
            () =>
            {
                var p = new Patient(1, "Тест Тестов", DateTime.Today.AddYears(-30).AddDays(1), "1", "a@b.kz");
                return p.GetAge() == 29;
            });

        Check("Пустой телефон и неверный email отклоняются",
            () => Throws<ArgumentException>(() => new Patient(1, "Тест Тестов", new DateTime(2000, 1, 1), " ", "a@b.kz"))
               && Throws<ArgumentException>(() => new Patient(1, "Тест Тестов", new DateTime(2000, 1, 1), "1", "без-собаки")));

        Check("UpdateProfile не оставляет частичных изменений при ошибке",
            () =>
            {
                var p = new Patient(1, "Иван Иванов", new DateTime(1990, 1, 1), "111", "a@b.kz");
                bool threw = Throws<ArgumentException>(() => p.UpdateProfile("Другое Имя", "222", "плохой", ""));
                return threw && p.FullName == "Иван Иванов" && p.PhoneNumber == "111";
            });

        Check("Стоимость услуги не может быть отрицательной",
            () =>
            {
                var s = new MedicalService(1, "ЭКГ", "", 5000m, TimeSpan.FromMinutes(20));
                return Throws<ArgumentException>(() => s.UpdatePrice(-1m))
                    && Throws<ArgumentException>(() => new MedicalService(2, "X", "", -5m, TimeSpan.FromMinutes(10)))
                    && s.Price == 5000m;
            });

        Check("CalculatePrice: количество и скидка",
            () => new MedicalService(1, "ЭКГ", "", 5000m, TimeSpan.FromMinutes(20)).CalculatePrice(2, 10m) == 9000m);

        Check("Композиция: у пациента всегда есть своя медкарта",
            () =>
            {
                var portal = new MedicalPortal();
                var p = portal.AddPatient("Иван Иванов", new DateTime(1990, 1, 1), "111", "a@b.kz");
                return p.Record != null && p.Record.Patient == p && p.Record.RecordId == p.PatientId;
            });

        Check("MedicalRecord: диагноз и история",
            () =>
            {
                var portal = new MedicalPortal();
                var p = portal.AddPatient("Иван Иванов", new DateTime(1990, 1, 1), "111", "a@b.kz");
                p.Record.AddDiagnosis("Гастрит");
                p.Record.UpdateHistory("Назначена диета");
                return p.Record.Diagnosis == "Гастрит" && p.Record.HistoryEntries.Count == 2
                    && Throws<ArgumentException>(() => p.Record.AddDiagnosis(" "));
            });

        Check("IPayable: оклад врача растёт со стажем (+2% за год)",
            () =>
            {
                var d = new Doctor(1, "Врач Врачов", new DateTime(1980, 1, 1), "Терапевт", 10, 101, 100000m);
                IPayable payable = d;
                return payable.CalculatePayment() == 120000m;
            });

        Check("Appointment реализует IPayable (цена услуги)",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out var service);
                var a = new Appointment(1, patient, doctor, NextMonday(), new TimeSpan(10, 0, 0), service);
                return a.CalculatePayment() == 8000m;
            });

        Check("IsDoctorAvailable: рабочее время, воскресенье, занятость",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var monday = NextMonday();
                bool ok = doctor.IsDoctorAvailable(monday.AddHours(10))
                       && !doctor.IsDoctorAvailable(monday.AddHours(8))
                       && !doctor.IsDoctorAvailable(monday.AddHours(18))
                       && !doctor.IsDoctorAvailable(monday.AddDays(6).AddHours(10));
                portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(10, 0, 0));
                return ok && !doctor.IsDoctorAvailable(monday.AddHours(10));
            });

        Check("Двойная запись запрещена, сообщение «Врач уже занят на указанное время!»",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var second = portal.AddPatient("Второй Пациент", new DateTime(1991, 2, 2), "222", "b@b.kz");
                var monday = NextMonday();
                var first = portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(11, 0, 0));
                var dup = portal.BookAppointment(second.PatientId, doctor.DoctorId, monday, new TimeSpan(11, 0, 0));
                return first.Ok && !dup.Ok
                    && dup.Message == "Врач уже занят на указанное время!"
                    && portal.Appointments.Count == 1;
            });

        Check("После отмены время врача освобождается",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var monday = NextMonday();
                var r1 = portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(12, 0, 0));
                var cancel = portal.CancelAppointment(1);
                var r2 = portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(12, 0, 0));
                return r1.Ok && cancel.Ok && r2.Ok;
            });

        Check("Запись на прошедшее время и в воскресенье отклоняется",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var past = portal.BookAppointment(patient.PatientId, doctor.DoctorId, DateTime.Today.AddDays(-2), new TimeSpan(10, 0, 0));
                var sunday = NextMonday().AddDays(6);
                var sun = portal.BookAppointment(patient.PatientId, doctor.DoctorId, sunday, new TimeSpan(10, 0, 0));
                return !past.Ok && !sun.Ok;
            });

        Check("Статусы записи: запланирован → подтверждён → завершён, отменить завершённую нельзя",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                portal.BookAppointment(patient.PatientId, doctor.DoctorId, NextMonday(), new TimeSpan(9, 0, 0));
                var a = portal.Appointments[0];
                bool s0 = a.Status == AppointmentStatus.Scheduled;
                bool noEarlyComplete = !a.CompleteAppointment();
                bool conf = a.ConfirmAppointment() && a.Status == AppointmentStatus.Confirmed;
                bool done = a.CompleteAppointment() && a.Status == AppointmentStatus.Completed;
                bool noCancel = !a.CancelAppointment();
                return s0 && noEarlyComplete && conf && done && noCancel;
            });

        Check("Ассоциации: у пациента и врача несколько записей",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var monday = NextMonday();
                portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(9, 0, 0));
                portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(9, 30, 0));
                return patient.Appointments.Count == 2 && doctor.Appointments.Count == 2
                    && patient.Appointments.All(a => a.Doctor == doctor)
                    && doctor.Appointments.All(a => a.Patient == patient);
            });

        Check("Агрегация: врач живёт независимо от отделения",
            () =>
            {
                var portal = new MedicalPortal();
                var dep = portal.AddDepartment("Терапия", 2, "555");
                var doc = portal.AddDoctor("Врач Врачов", new DateTime(1980, 1, 1), "Терапевт", 5, 101, 100000m);
                bool added = dep.AddDoctor(doc) && doc.Department == dep && !dep.AddDoctor(doc);
                dep.SetHeadDoctor(doc);
                bool removed = dep.RemoveDoctor(doc) && doc.Department == null && dep.HeadDoctor == null;
                return added && removed && portal.Doctors.Contains(doc) && dep.Doctors.Count == 0;
            });

        Check("MedicalTest: результат вносится один раз, затем только обновляется",
            () =>
            {
                var portal = Seeded(out var patient, out _, out _);
                var t = portal.AddTest(patient.PatientId, "Анализ крови", DateTime.Today);
                bool noUpdateEarly = Throws<InvalidOperationException>(() => t.UpdateResult("x"));
                t.AddResult("Норма");
                bool noDoubleAdd = Throws<InvalidOperationException>(() => t.AddResult("ещё"));
                t.UpdateResult("Повышен гемоглобин");
                return noUpdateEarly && noDoubleAdd && t.Result == "Повышен гемоглобин"
                    && patient.Tests.Count == 1;
            });

        Check("Prescription: оформление и изменение, курс 1–365 дней",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var p = portal.CreatePrescription(patient.PatientId, doctor.DoctorId, "Парацетамол", "500 мг 2 раза", 3);
                p.UpdatePrescription("Парацетамол", "500 мг 3 раза", 5);
                return p.IsCreated && p.Duration == 5 && patient.Prescriptions.Count == 1
                    && !p.CreatePrescription()
                    && Throws<ArgumentException>(() => p.UpdatePrescription("X", "Y", 0));
            });

        Check("Payment: оплата, возврат, повторный возврат невозможен",
            () =>
            {
                var portal = Seeded(out var patient, out _, out var service);
                var pay = portal.PayForService(patient.PatientId, service.ServiceId);
                var ref1 = portal.RefundPayment(1);
                var ref2 = portal.RefundPayment(1);
                return pay.Ok && ref1.Ok && !ref2.Ok
                    && portal.Payments[0].PaymentStatus == PaymentStatus.Refunded;
            });

        Check("Поиск пациента: по номеру, ФИО и телефону; не найден — пустой результат",
            () =>
            {
                var portal = new MedicalPortal();
                portal.AddPatient("Жумабаева Айгерим", new DateTime(1995, 3, 14), "+7 701 123-45-67", "a@b.kz");
                portal.AddPatient("Петров Сергей", new DateTime(1988, 11, 2), "+7 707 222-33-44", "p@b.kz");
                return portal.FindPatientById(2)?.FullName == "Петров Сергей"
                    && portal.FindPatientById(99) == null
                    && portal.FindPatientsByName("айгер").Count == 1
                    && portal.FindPatientsByPhone("707 222").Count == 1
                    && portal.FindPatientsByPhone("7011234567").Count == 1
                    && portal.FindPatientsByName("Сидоров").Count == 0
                    && portal.FindPatientsByName("  ").Count == 0;
            });

        Check("Статистика: пациенты, врачи, записи, завершённые, сумма оплат",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out var service);
                var monday = NextMonday();
                portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(9, 0, 0));
                portal.BookAppointment(patient.PatientId, doctor.DoctorId, monday, new TimeSpan(9, 30, 0));
                portal.ConfirmAppointment(1);
                portal.CompleteAppointment(1);
                portal.PayForService(patient.PatientId, service.ServiceId);
                portal.PayForService(patient.PatientId, service.ServiceId);
                portal.RefundPayment(2);
                var s = portal.GetStatistics();
                return s.Patients == 1 && s.Doctors == 1 && s.Appointments == 2
                    && s.Completed == 1 && s.PaidTotal == 8000m;
            });

        Check("Заявления: нельзя одобрить без врача и его рекомендации",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var r = portal.AddRequest(patient.PatientId, RequestType.SickLeave, "ОРВИ");
                r.ChangeStatus(RequestStatus.UnderReview);
                bool noDoctor = Throws<InvalidOperationException>(() => r.ChangeStatus(RequestStatus.Approved));
                r.AssignDoctor(doctor);
                bool noRecommendation = Throws<InvalidOperationException>(() => r.ChangeStatus(RequestStatus.Approved));
                r.SetDoctorRecommendation(doctor, true, "Домашний режим");
                r.ChangeStatus(RequestStatus.Approved);
                return noDoctor && noRecommendation && r.Status == RequestStatus.Approved;
            });

        Check("Заявления: отказ требует причину, «Завершено» — номер документа, пропуск статусов запрещён",
            () =>
            {
                var portal = Seeded(out var patient, out var doctor, out _);
                var r = portal.AddRequest(patient.PatientId, RequestType.Certificate, "Справка");
                bool skip = Throws<InvalidOperationException>(() => r.ChangeStatus(RequestStatus.Completed));
                bool noReason = Throws<ArgumentException>(() => r.ChangeStatus(RequestStatus.Rejected, " "));
                r.ChangeStatus(RequestStatus.Rejected, "Недостаточно данных");
                bool final = Throws<InvalidOperationException>(() => r.ChangeStatus(RequestStatus.UnderReview));

                var r2 = portal.AddRequest(patient.PatientId, RequestType.SickLeave, "Грипп");
                r2.ChangeStatus(RequestStatus.UnderReview);
                r2.AssignDoctor(doctor);
                r2.SetDoctorRecommendation(doctor, true, "ОК");
                r2.ChangeStatus(RequestStatus.Approved);
                bool noDoc = Throws<ArgumentException>(() => r2.ChangeStatus(RequestStatus.Completed));
                r2.ChangeStatus(RequestStatus.Completed, null, "БЛ-0001");
                return skip && noReason && final && noDoc && r2.DocumentNumber == "БЛ-0001";
            });

        Check("Демо-данные загружаются без ошибок и согласованы",
            () =>
            {
                var portal = new MedicalPortal();
                DemoData.Seed(portal);
                var s = portal.GetStatistics();
                return s.Patients == 5 && s.Doctors == 4 && s.Departments == 4
                    && s.Appointments == 5 && s.Completed == 1 && s.Cancelled == 1
                    && s.PaidTotal == 25000m && portal.Requests.Count == 2;
            });

        Console.WriteLine(new string('-', 60));
        Console.WriteLine($"Итого: успешно {_passed}, с ошибкой {_failed}");
        return _failed == 0 ? 0 : 1;
    }

    // ---------- вспомогательное --------------------------------------

    private static MedicalPortal Seeded(out Patient patient, out Doctor doctor, out MedicalService service)
    {
        var portal = new MedicalPortal();
        patient = portal.AddPatient("Иван Иванов", new DateTime(1990, 1, 1), "+7 700 000-00-01", "ivan@mail.kz");
        doctor = portal.AddDoctor("Врач Врачов", new DateTime(1980, 1, 1), "Терапевт", 10, 101, 100000m);
        service = portal.AddService("Приём терапевта", "", 8000m, 30);
        return portal;
    }

    /// <summary>Ближайший будущий понедельник (всегда рабочий день и точно в будущем).</summary>
    private static DateTime NextMonday()
    {
        var d = DateTime.Today.AddDays(1);
        while (d.DayOfWeek != DayOfWeek.Monday) d = d.AddDays(1);
        return d;
    }

    private static bool Throws<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T) { return true; }
        return false;
    }

    private static void Check(string name, Func<bool> test)
    {
        bool ok;
        string error = "";
        try { ok = test(); }
        catch (Exception ex) { ok = false; error = " (" + ex.GetType().Name + ": " + ex.Message + ")"; }

        if (ok) _passed++; else _failed++;
        Console.ForegroundColor = ok ? ConsoleColor.Green : ConsoleColor.Red;
        Console.Write(ok ? "  [PASS] " : "  [FAIL] ");
        Console.ResetColor();
        Console.WriteLine(name + error);
    }
}
