using System.Globalization;
using System.Text;

namespace VitaPortal.UI;

/// <summary>
/// Оформление консоли: цвета, рамки, таблицы, карточки и ввод с проверкой.
/// Запуск с ключом --ascii включает простые символы (если консоль не показывает рамки).
/// </summary>
public static class ConsoleUi
{
    public static bool Ascii { get; set; }

    // ---- палитра -------------------------------------------------------
    private const ConsoleColor Accent = ConsoleColor.Cyan;
    private const ConsoleColor Muted = ConsoleColor.DarkGray;
    private const ConsoleColor Text = ConsoleColor.White;
    private const ConsoleColor Good = ConsoleColor.Green;
    private const ConsoleColor Bad = ConsoleColor.Red;
    private const ConsoleColor Warn = ConsoleColor.Yellow;

    // ---- символы -------------------------------------------------------
    private static string S(string unicode, string ascii) => Ascii ? ascii : unicode;
    private static string H => S("─", "-");
    private static string V => S("│", "|");
    private static string TL => S("┌", "+");
    private static string TR => S("┐", "+");
    private static string BL => S("└", "+");
    private static string BR => S("┘", "+");
    private static string LT => S("├", "+");
    private static string RT => S("┤", "+");
    private static string TT => S("┬", "+");
    private static string BT => S("┴", "+");
    private static string CR => S("┼", "+");
    private static string DH => S("═", "=");
    private static string DV => S("║", "|");
    private static string DTL => S("╔", "+");
    private static string DTR => S("╗", "+");
    private static string DBL => S("╚", "+");
    private static string DBR => S("╝", "+");

    public static void Setup()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
    }

    // ---- форматирование ------------------------------------------------
    public static string Money(decimal value) =>
        value.ToString("#,0.##", CultureInfo.InvariantCulture).Replace(',', ' ') + " ₸";

    public static string Cut(string? s, int max)
    {
        s ??= "";
        s = s.Replace('\n', ' ').Replace('\r', ' ');
        return s.Length <= max ? s : s.Substring(0, max - 1) + "…";
    }

    // ---- вывод ---------------------------------------------------------
    private static void W(string text, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.Write(text);
        Console.ResetColor();
    }

    private static void WL(string text, ConsoleColor color)
    {
        W(text, color);
        Console.WriteLine();
    }

    public static void Clear()
    {
        try { Console.Clear(); } catch (IOException) { /* вывод перенаправлен в файл */ }
    }

    public static void Banner(string appName, string subtitle)
    {
        const int inner = 56;
        W("  " + DTL + new string(DH[0], inner) + DTR + "\n", Accent);
        W("  " + DV, Accent);
        W(("  " + S("✚ ", "[+] ") + appName).PadRight(inner), Text);
        W(DV + "\n", Accent);
        W("  " + DV, Accent);
        W(("    " + subtitle).PadRight(inner), Muted);
        W(DV + "\n", Accent);
        W("  " + DBL + new string(DH[0], inner) + DBR + "\n", Accent);
    }

    public static void Title(string text)
    {
        Console.WriteLine();
        W("  " + S("▌ ", "> "), Accent);
        WL(text.ToUpperInvariant(), Text);
        WL("  " + new string(H[0], Math.Max(text.Length + 2, 20)), Muted);
    }

    public static void Group(string text)
    {
        Console.WriteLine();
        WL("  " + text.ToUpperInvariant(), Muted);
    }

    public static void MenuItem(string key, string text)
    {
        W("   " + key.PadLeft(2) + "  ", Accent);
        WL(text, Text);
    }

    public static void Success(string message) => WL("  " + S("✔ ", "[OK] ") + message, Good);
    public static void Error(string message) => WL("  " + S("✖ ", "[!] ") + message, Bad);
    public static void Warning(string message) => WL("  " + S("▲ ", "[!] ") + message, Warn);
    public static void Info(string message) => WL("  " + S("• ", "- ") + message, Muted);
    public static void Line(string message) => WL("  " + message, Text);

    public static void Card(string title, params (string Label, string Value)[] rows)
    {
        int lw = rows.Length == 0 ? 0 : rows.Max(r => r.Label.Length);
        int vw = rows.Length == 0 ? 0 : rows.Max(r => r.Value.Length);
        int inner = Math.Max(title.Length + 4, lw + vw + 5);

        W("  " + TL + H + " ", Accent);
        W(title, Text);
        W(" " + new string(H[0], inner - title.Length - 3) + TR + "\n", Accent);

        foreach (var (label, value) in rows)
        {
            W("  " + V + " ", Accent);
            W(label.PadRight(lw) + "  ", Muted);
            W(value.PadRight(inner - lw - 3), Text);
            W(V + "\n", Accent);
        }

        W("  " + BL + new string(H[0], inner) + BR + "\n", Accent);
    }

    public static void Table(string[] headers, IEnumerable<string[]> rows, int maxCell = 30)
    {
        var data = rows.Select(r => r.Select(c => Cut(c, maxCell)).ToArray()).ToList();
        if (data.Count == 0)
        {
            Info("Список пока пуст.");
            return;
        }

        var widths = headers.Select(h => h.Length).ToArray();
        foreach (var r in data)
            for (int i = 0; i < widths.Length && i < r.Length; i++)
                widths[i] = Math.Max(widths[i], r[i].Length);

        string Border(string left, string mid, string right) =>
            "  " + left + string.Join(mid, widths.Select(w => new string(H[0], w + 2))) + right;

        WL(Border(TL, TT, TR), Accent);

        W("  " + V, Accent);
        for (int i = 0; i < widths.Length; i++)
        {
            W(" " + headers[i].PadRight(widths[i]) + " ", Accent);
            W(V, Accent);
        }
        Console.WriteLine();

        WL(Border(LT, CR, RT), Accent);

        foreach (var r in data)
        {
            W("  " + V, Accent);
            for (int i = 0; i < widths.Length; i++)
            {
                string cell = i < r.Length ? r[i] : "";
                W(" " + cell.PadRight(widths[i]) + " ", Text);
                W(V, Accent);
            }
            Console.WriteLine();
        }

        WL(Border(BL, BT, BR), Accent);
        Info($"Всего: {data.Count}");
    }

    // ---- ввод ----------------------------------------------------------
    private static string? ReadLine(string label)
    {
        W("  " + S("› ", "> ") + label + ": ", Accent);
        var s = Console.ReadLine();
        if (s == null) throw new EndOfStreamException("Ввод закрыт.");
        return s.Trim();
    }

    public static string Ask(string label, bool required = true)
    {
        while (true)
        {
            var s = ReadLine(label) ?? "";
            if (s.Length > 0 || !required) return s;
            Error("Поле не может быть пустым.");
        }
    }

    public static int AskInt(string label, int min = int.MinValue, int max = int.MaxValue)
    {
        while (true)
        {
            var s = ReadLine(label);
            if (int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int v) && v >= min && v <= max)
                return v;
            Error(max == int.MaxValue
                ? $"Введите целое число не меньше {min}."
                : $"Введите целое число от {min} до {max}.");
        }
    }

    public static decimal AskDecimal(string label, decimal min = 0)
    {
        while (true)
        {
            var s = (ReadLine(label) ?? "").Replace(',', '.').Replace(" ", "");
            if (decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal v) && v >= min)
                return v;
            Error($"Введите число не меньше {min}.");
        }
    }

    private static readonly string[] DateFormats = { "dd.MM.yyyy", "d.M.yyyy", "yyyy-MM-dd" };

    public static bool TryParseDate(string? text, out DateTime date)
    {
        bool ok = DateTime.TryParseExact(text, DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out date);
        date = date.Date;
        return ok;
    }

    public static DateTime AskDate(string label)
    {
        while (true)
        {
            var s = ReadLine(label + " (дд.мм.гггг)");
            if (TryParseDate(s, out var d)) return d;
            Error("Неверная дата. Пример: 25.11.2026");
        }
    }

    public static TimeSpan AskTime(string label)
    {
        while (true)
        {
            var s = ReadLine(label + " (чч:мм)");
            if (TimeSpan.TryParseExact(s, @"h\:mm", CultureInfo.InvariantCulture, out var t) && t < TimeSpan.FromHours(24))
                return t;
            Error("Неверное время. Пример: 14:30");
        }
    }

    public static bool Confirm(string label)
    {
        while (true)
        {
            var s = (ReadLine(label + " (д/н)") ?? "").ToLowerInvariant();
            if (s is "д" or "да" or "y" or "yes") return true;
            if (s is "н" or "нет" or "n" or "no") return false;
        }
    }

    public static void Pause()
    {
        Console.WriteLine();
        W("  Нажмите Enter, чтобы вернуться в меню…", Muted);
        Console.ReadLine();
    }
}
