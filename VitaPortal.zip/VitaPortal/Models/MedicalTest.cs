using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>Медицинский анализ или исследование (задача 10).</summary>
public class MedicalTest
{
    public int TestId { get; }
    public string TestName { get; }
    public DateTime TestDate { get; }
    public Patient Patient { get; }
    public string? Result { get; private set; }

    public bool HasResult => !string.IsNullOrWhiteSpace(Result);

    public MedicalTest(int id, string testName, DateTime testDate, Patient patient)
    {
        TestId = id;
        TestName = Guard.NotBlank(testName, "Название анализа");
        TestDate = testDate.Date;
        Patient = Guard.NotNull(patient, nameof(patient));
    }

    public void AddResult(string result)
    {
        if (HasResult)
            throw new InvalidOperationException("Результат уже внесён. Используйте изменение результата.");
        Result = Guard.NotBlank(result, "Результат");
    }

    public void UpdateResult(string result)
    {
        if (!HasResult)
            throw new InvalidOperationException("Результата ещё нет. Сначала внесите его.");
        Result = Guard.NotBlank(result, "Результат");
    }

    public void DisplayResult() =>
        ConsoleUi.Card($"Анализ №{TestId}",
            ("Пациент", Patient.FullName),
            ("Исследование", TestName),
            ("Дата", TestDate.ToString("dd.MM.yyyy")),
            ("Результат", HasResult ? Result! : "ожидается"));
}
