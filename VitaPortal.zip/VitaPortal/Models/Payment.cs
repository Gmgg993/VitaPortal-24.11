using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>Оплата медицинских услуг (задача 21).</summary>
public class Payment
{
    public int PaymentId { get; }
    public Patient Patient { get; }
    public MedicalService? Service { get; }
    public decimal Amount { get; }
    public DateTime? PaymentDate { get; private set; }
    public PaymentStatus PaymentStatus { get; private set; } = PaymentStatus.Pending;

    public Payment(int id, Patient patient, decimal amount, MedicalService? service = null)
    {
        if (amount <= 0) throw new ArgumentException("Сумма оплаты должна быть больше нуля.");
        PaymentId = id;
        Patient = Guard.NotNull(patient, nameof(patient));
        Amount = amount;
        Service = service;
    }

    public bool MakePayment()
    {
        if (PaymentStatus != PaymentStatus.Pending) return false;
        PaymentStatus = PaymentStatus.Paid;
        PaymentDate = DateTime.Now;
        return true;
    }

    public bool RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid) return false;
        PaymentStatus = PaymentStatus.Refunded;
        return true;
    }

    public void DisplayPayment() =>
        ConsoleUi.Card($"Платёж №{PaymentId}",
            ("Пациент", Patient.FullName),
            ("Услуга", Service?.ServiceName ?? "—"),
            ("Сумма", ConsoleUi.Money(Amount)),
            ("Дата", PaymentDate?.ToString("dd.MM.yyyy HH:mm") ?? "—"),
            ("Статус", EnumText.Ru(PaymentStatus)));
}
