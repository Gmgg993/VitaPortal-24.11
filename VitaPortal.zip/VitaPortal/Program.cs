using VitaPortal.Diagnostics;
using VitaPortal.Services;
using VitaPortal.UI;
using VitaPortal.Web;

ConsoleUi.Setup();

// Ключи запуска:
//   --web         запустить сайт вместо консольного меню (http://localhost:5000)
//   --port N      порт сайта (по умолчанию 5000)
//   --no-browser  не открывать браузер автоматически
//   --ascii       простые символы вместо рамок (если консоль их не показывает)
//   --empty       запуск без демонстрационных данных
//   --selftest    автоматическая проверка основных сценариев
if (args.Contains("--ascii")) ConsoleUi.Ascii = true;

if (args.Contains("--selftest"))
{
    return SelfTest.Run();
}

var portal = new MedicalPortal();
if (!args.Contains("--empty")) DemoData.Seed(portal);

if (args.Contains("--web"))
{
    int webPort = 5000;
    int portIndex = Array.IndexOf(args, "--port");
    if (portIndex >= 0 && portIndex + 1 < args.Length && int.TryParse(args[portIndex + 1], out int parsed))
        webPort = parsed;
    return WebServer.Run(portal, webPort, openBrowser: !args.Contains("--no-browser"));
}

new MainMenu(portal).Run();
return 0;
