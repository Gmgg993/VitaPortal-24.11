namespace VitaPortal.Models;

/// <summary>Объект, который может рассчитать выплату или сумму к оплате (задача 18).</summary>
public interface IPayable
{
    decimal CalculatePayment();
}
