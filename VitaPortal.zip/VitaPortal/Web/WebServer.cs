using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using VitaPortal.Models;
using VitaPortal.Services;

namespace VitaPortal.Web;

/// <summary>
/// Веб-режим портала (dotnet run -- --web). Использует те же Models/ и Services/, что и консоль:
/// вся бизнес-логика и проверки остаются в C#, браузер только показывает данные и вызывает API.
/// Данные хранятся в памяти процесса — как и в консольном режиме.
/// </summary>
public static class WebServer
{
    private static readonly object Gate = new();   // MedicalPortal не потокобезопасен: все вызовы идут по одному

    public static int Run(MedicalPortal portal, int port, bool openBrowser)
    {
        try
        {
            var builder = WebApplication.CreateBuilder();
            builder.WebHost.UseUrls($"http://localhost:{port}");
            builder.Logging.SetMinimumLevel(LogLevel.Warning);
            var app = builder.Build();

            string html = LoadHtml();
            app.MapGet("/", () => Results.Content(html, "text/html; charset=utf-8"));
            MapApi(app, portal);

            string url = $"http://localhost:{port}";
            app.Lifetime.ApplicationStarted.Register(() =>
            {
                Console.WriteLine();
                Console.WriteLine($"  VitaPortal (веб) запущен: {url}");
                Console.WriteLine("  Остановить: Ctrl+C");
                if (!openBrowser) return;
                try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
                catch { /* браузер не открылся — адрес уже выведен выше */ }
            });

            app.Run();
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Не удалось запустить сайт: {ex.Message}");
            Console.Error.WriteLine("Попробуйте другой порт: dotnet run -- --web --port 5050");
            return 1;
        }
    }

    private static string LoadHtml()
    {
        using var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("index.html")
                      ?? throw new InvalidOperationException("Не найден встроенный файл Web/index.html.");
        using var r = new StreamReader(s);
        return r.ReadToEnd();
    }

    // ---------- вспомогательное -----------------------------------------

    /// <summary>Выполняет действие под блокировкой и превращает ошибки проверки в понятный ответ 400.</summary>
    private static IResult Do(Func<string> action)
    {
        lock (Gate)
        {
            try
            {
                return Results.Ok(new { ok = true, message = action() });
            }
            catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or FormatException)
            {
                return Results.BadRequest(new { ok = false, message = ex.Message });
            }
        }
    }

    private static string Check(OpResult r) =>
        r.Ok ? r.Message : throw new InvalidOperationException(r.Message);

    private static T Need<T>(T? v, string field) where T : struct =>
        v ?? throw new ArgumentException($"Поле «{field}» не заполнено.");

    private static string Str(string? v) => v ?? "";

    private static string Day(DateTime d) => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    private static string Stamp(DateTime? d) => d?.ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture) ?? "—";

    private static DateTime ParseDate(string? s, string field)
    {
        if (!DateTime.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
            throw new ArgumentException($"Укажите дату: «{field}».");
        return d;
    }

    private static TimeSpan ParseTime(string? s)
    {
        if (!TimeSpan.TryParse(s, CultureInfo.InvariantCulture, out var t) || t < TimeSpan.Zero || t >= TimeSpan.FromDays(1))
            throw new ArgumentException("Укажите время в формате чч:мм.");
        return t;
    }

    private static T ParseEnum<T>(string? s, string field) where T : struct, Enum =>
        Enum.TryParse<T>(s, out var v) && Enum.IsDefined(v)
            ? v
            : throw new ArgumentException($"Неверное значение поля «{field}».");

    private static Patient GetPatient(MedicalPortal p, int id) =>
        p.FindPatient(id) ?? throw new ArgumentException($"Пациент с номером {id} не найден.");

    private static Doctor GetDoctor(MedicalPortal p, int id) =>
        p.FindDoctor(id) ?? throw new ArgumentException($"Врач с номером {id} не найден.");

    private static Department GetDept(MedicalPortal p, int id) =>
        p.FindDepartment(id) ?? throw new ArgumentException($"Отделение с номером {id} не найдено.");

    private static SickLeaveRequest GetRequest(MedicalPortal p, int id) =>
        p.FindRequest(id) ?? throw new ArgumentException($"Заявление №{id} не найдено.");

    // ---------- состояние для браузера ----------------------------------

    private static object Snapshot(MedicalPortal p)
    {
        var st = p.GetStatistics();
        return new
        {
            stats = new
            {
                patients = st.Patients, doctors = st.Doctors, departments = st.Departments,
                appointments = st.Appointments, completed = st.Completed, cancelled = st.Cancelled,
                paidPayments = st.PaidPayments, paidTotal = st.PaidTotal
            },
            patients = p.Patients.Select(x => new
            {
                id = x.PatientId, name = x.FullName, birth = Day(x.BirthDate), age = x.GetAge(),
                phone = x.PhoneNumber, email = x.Email, address = x.Address,
                diagnosis = x.Record.Diagnosis, history = x.Record.HistoryEntries.ToList()
            }).ToList(),
            doctors = p.Doctors.Select(d => new
            {
                id = d.DoctorId, name = d.FullName, specialization = d.Specialization,
                experience = d.Experience, cabinet = d.CabinetNumber, salary = d.Salary,
                toPay = d.CalculateSalary(), departmentId = d.Department?.DepartmentId
            }).ToList(),
            departments = p.Departments.Select(d => new
            {
                id = d.DepartmentId, name = d.DepartmentName, floor = d.Floor, phone = d.PhoneNumber,
                headId = d.HeadDoctor?.DoctorId
            }).ToList(),
            services = p.Services.Select(s => new
            {
                id = s.ServiceId, name = s.ServiceName, description = s.Description,
                price = s.Price, minutes = (int)s.Duration.TotalMinutes
            }).ToList(),
            appointments = p.Appointments.Select(a => new
            {
                id = a.AppointmentId, patientId = a.Patient.PatientId, doctorId = a.Doctor.DoctorId,
                serviceId = a.Service?.ServiceId, date = Day(a.AppointmentDate),
                time = a.AppointmentTime.ToString(@"hh\:mm"), status = a.Status.ToString()
            }).ToList(),
            tests = p.Tests.Select(t => new
            {
                id = t.TestId, patientId = t.Patient.PatientId, name = t.TestName,
                date = Day(t.TestDate), result = t.Result ?? ""
            }).ToList(),
            prescriptions = p.Prescriptions.Select(r => new
            {
                id = r.PrescriptionId, patientId = r.Patient.PatientId, doctorId = r.Doctor.DoctorId,
                medication = r.MedicationName, dosage = r.Dosage, days = r.Duration, date = Day(r.IssuedDate)
            }).ToList(),
            payments = p.Payments.Select(x => new
            {
                id = x.PaymentId, patientId = x.Patient.PatientId, serviceId = x.Service?.ServiceId,
                amount = x.Amount, date = Stamp(x.PaymentDate), status = x.PaymentStatus.ToString()
            }).ToList(),
            requests = p.Requests.Select(r => new
            {
                id = r.RequestId, patientId = r.Patient.PatientId, type = r.Type.ToString(),
                reason = r.Reason, created = Stamp(r.CreatedAt), status = r.Status.ToString(),
                doctorId = r.AssignedDoctor?.DoctorId, recommend = r.DoctorRecommendsApproval,
                comment = r.DoctorComment, document = r.DocumentNumber ?? ""
            }).ToList()
        };
    }

    // ---------- API ------------------------------------------------------

    private static void MapApi(WebApplication app, MedicalPortal portal)
    {
        app.MapGet("/api/state", () => { lock (Gate) { return Results.Json(Snapshot(portal)); } });

        // пациенты
        app.MapPost("/api/patients", (PatientIn b) => Do(() =>
        {
            var p = portal.AddPatient(Str(b.Name), ParseDate(b.Birth, "Дата рождения"), Str(b.Phone), Str(b.Email), Str(b.Address));
            return $"Пациент №{p.PatientId} добавлен.";
        }));
        app.MapPut("/api/patients/{id:int}", (int id, PatientIn b) => Do(() =>
        {
            GetPatient(portal, id).UpdateProfile(Str(b.Name), Str(b.Phone), Str(b.Email), Str(b.Address));
            return "Профиль обновлён.";
        }));
        app.MapPost("/api/patients/{id:int}/diagnosis", (int id, TextIn b) => Do(() =>
        {
            GetPatient(portal, id).Record.AddDiagnosis(Str(b.Text));
            return "Диагноз установлен.";
        }));
        app.MapPost("/api/patients/{id:int}/history", (int id, TextIn b) => Do(() =>
        {
            GetPatient(portal, id).Record.UpdateHistory(Str(b.Text));
            return "Запись добавлена.";
        }));
        app.MapPost("/api/patients/{id:int}/tests", (int id, TestIn b) => Do(() =>
        {
            var date = string.IsNullOrWhiteSpace(b.Date) ? DateTime.Today : ParseDate(b.Date, "Дата");
            portal.AddTest(id, Str(b.Name), date, b.Result);
            return "Анализ добавлен.";
        }));
        app.MapPost("/api/tests/{id:int}/result", (int id, TextIn b) => Do(() =>
        {
            var t = portal.FindTest(id) ?? throw new ArgumentException($"Анализ №{id} не найден.");
            if (t.HasResult) t.UpdateResult(Str(b.Text)); else t.AddResult(Str(b.Text));
            return "Результат сохранён.";
        }));
        app.MapPost("/api/patients/{id:int}/prescriptions", (int id, RxIn b) => Do(() =>
        {
            portal.CreatePrescription(id, Need(b.DoctorId, "Врач"), Str(b.Medication), Str(b.Dosage), Need(b.Days, "Длительность курса"));
            return "Назначение оформлено.";
        }));

        // врачи
        app.MapPost("/api/doctors", (DoctorIn b) => Do(() =>
        {
            var d = portal.AddDoctor(Str(b.Name), ParseDate(b.Birth, "Дата рождения"), Str(b.Specialization),
                Need(b.Experience, "Стаж"), Need(b.Cabinet, "Кабинет"), Need(b.Salary, "Оклад"));
            return $"Врач №{d.DoctorId} добавлен.";
        }));

        // приёмы
        app.MapPost("/api/appointments", (BookIn b) => Do(() =>
            Check(portal.BookAppointment(Need(b.PatientId, "Пациент"), Need(b.DoctorId, "Врач"),
                ParseDate(b.Date, "Дата"), ParseTime(b.Time), b.ServiceId))));
        app.MapPost("/api/appointments/{id:int}/{action}", (int id, string action) => Do(() =>
        {
            var r = action switch
            {
                "confirm" => portal.ConfirmAppointment(id),
                "complete" => portal.CompleteAppointment(id),
                "cancel" => portal.CancelAppointment(id),
                _ => throw new ArgumentException("Неизвестное действие.")
            };
            return Check(r);
        }));

        // оплата
        app.MapPost("/api/payments", (PayIn b) => Do(() =>
            Check(portal.PayForService(Need(b.PatientId, "Пациент"), Need(b.ServiceId, "Услуга"),
                b.Quantity ?? 1, b.Discount ?? 0m))));
        app.MapPost("/api/payments/{id:int}/refund", (int id) => Do(() => Check(portal.RefundPayment(id))));

        // отделения и услуги
        app.MapPost("/api/departments", (DeptIn b) => Do(() =>
        {
            portal.AddDepartment(Str(b.Name), Need(b.Floor, "Этаж"), Str(b.Phone));
            return "Отделение добавлено.";
        }));
        app.MapPost("/api/departments/{id:int}/add-doctor", (int id, DoctorRefIn b) => Do(() =>
        {
            var doc = GetDoctor(portal, Need(b.DoctorId, "Врач"));
            return GetDept(portal, id).AddDoctor(doc)
                ? "Врач добавлен в отделение."
                : throw new InvalidOperationException("Этот врач уже работает в отделении.");
        }));
        app.MapPost("/api/departments/{id:int}/remove-doctor", (int id, DoctorRefIn b) => Do(() =>
        {
            var doc = GetDoctor(portal, Need(b.DoctorId, "Врач"));
            return GetDept(portal, id).RemoveDoctor(doc)
                ? "Врач убран из отделения."
                : throw new InvalidOperationException("Этого врача нет в отделении.");
        }));
        app.MapPost("/api/departments/{id:int}/head", (int id, DoctorRefIn b) => Do(() =>
        {
            var doc = GetDoctor(portal, Need(b.DoctorId, "Врач"));
            return GetDept(portal, id).SetHeadDoctor(doc)
                ? "Заведующий назначен."
                : throw new InvalidOperationException("Заведующим может быть только врач этого отделения.");
        }));
        app.MapPost("/api/services", (ServiceIn b) => Do(() =>
        {
            portal.AddService(Str(b.Name), Str(b.Description), Need(b.Price, "Стоимость"), Need(b.Minutes, "Длительность"));
            return "Услуга добавлена.";
        }));
        app.MapPost("/api/services/{id:int}/price", (int id, PriceIn b) => Do(() =>
        {
            var s = portal.FindService(id) ?? throw new ArgumentException($"Услуга с номером {id} не найдена.");
            s.UpdatePrice(Need(b.Price, "Стоимость"));
            return "Стоимость обновлена.";
        }));

        // заявления на больничный и справки
        app.MapPost("/api/requests", (RequestIn b) => Do(() =>
        {
            portal.AddRequest(Need(b.PatientId, "Пациент"), ParseEnum<RequestType>(b.Type, "Тип"), Str(b.Reason));
            return "Заявление подано (статус «Новое»).";
        }));
        app.MapPost("/api/requests/{id:int}/doctor", (int id, DoctorRefIn b) => Do(() =>
        {
            GetRequest(portal, id).AssignDoctor(GetDoctor(portal, Need(b.DoctorId, "Врач")));
            return "Врач назначен.";
        }));
        app.MapPost("/api/requests/{id:int}/recommendation", (int id, RecIn b) => Do(() =>
        {
            var r = GetRequest(portal, id);
            var doc = r.AssignedDoctor ?? throw new InvalidOperationException("Сначала назначьте врача.");
            r.SetDoctorRecommendation(doc, Need(b.Recommend, "Рекомендация"), Str(b.Comment));
            return "Заключение сохранено.";
        }));
        app.MapPost("/api/requests/{id:int}/status", (int id, StatusIn b) => Do(() =>
        {
            var r = GetRequest(portal, id);
            r.ChangeStatus(ParseEnum<RequestStatus>(b.Status, "Статус"), b.Text, b.Text);
            return "Статус изменён.";
        }));
    }
}

// тела запросов
public record PatientIn(string? Name, string? Birth, string? Phone, string? Email, string? Address);
public record TextIn(string? Text);
public record TestIn(string? Name, string? Date, string? Result);
public record RxIn(int? DoctorId, string? Medication, string? Dosage, int? Days);
public record DoctorIn(string? Name, string? Birth, string? Specialization, int? Experience, int? Cabinet, decimal? Salary);
public record BookIn(int? PatientId, int? DoctorId, int? ServiceId, string? Date, string? Time);
public record PayIn(int? PatientId, int? ServiceId, int? Quantity, decimal? Discount);
public record DeptIn(string? Name, int? Floor, string? Phone);
public record DoctorRefIn(int? DoctorId);
public record ServiceIn(string? Name, string? Description, decimal? Price, int? Minutes);
public record PriceIn(decimal? Price);
public record RequestIn(int? PatientId, string? Type, string? Reason);
public record RecIn(bool? Recommend, string? Comment);
public record StatusIn(string? Status, string? Text);
