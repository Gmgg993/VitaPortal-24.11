using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>Абстрактный базовый класс для всех людей в системе (задача 16).</summary>
public abstract class Person
{
    private string _fullName = "";
    private DateTime _birthDate;

    public int Id { get; }

    public string FullName
    {
        get => _fullName;
        set => _fullName = Guard.NotBlank(value, "ФИО");
    }

    public DateTime BirthDate
    {
        get => _birthDate;
        set
        {
            if (value.Date > DateTime.Today)
                throw new ArgumentException("Дата рождения не может быть в будущем (возраст не может быть отрицательным).");
            if (value.Year < 1900)
                throw new ArgumentException("Дата рождения указана неверно.");
            _birthDate = value.Date;
        }
    }

    protected Person(int id, string fullName, DateTime birthDate)
    {
        Id = id;
        FullName = fullName;
        BirthDate = birthDate;
    }

    /// <summary>Полных лет на сегодня.</summary>
    public int GetAge()
    {
        var today = DateTime.Today;
        int age = today.Year - _birthDate.Year;
        if (_birthDate.Date > today.AddYears(-age)) age--;
        return Math.Max(age, 0);
    }

    protected string BirthText() => $"{_birthDate:dd.MM.yyyy}  ({GetAge()} полных лет)";

    public abstract void DisplayInfo();
}
