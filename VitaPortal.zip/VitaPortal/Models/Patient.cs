using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>
/// Пациент (задачи 2, 11, 14, 17).
/// Наследует Person. Связан с Appointment (1 — 0..*) и владеет MedicalRecord (композиция 1 — 1).
/// </summary>
public class Patient : Person
{
    private string _phone = "";
    private string _email = "";
    private string _address = "";

    private readonly List<Appointment> _appointments = new();
    private readonly List<MedicalTest> _tests = new();
    private readonly List<Prescription> _prescriptions = new();

    public int PatientId => Id;

    public string PhoneNumber
    {
        get => _phone;
        set => _phone = Guard.NotBlank(value, "Телефон");
    }

    public string Email
    {
        get => _email;
        set => _email = Guard.Email(value);
    }

    public string Address
    {
        get => _address;
        set => _address = string.IsNullOrWhiteSpace(value) ? "не указан" : value.Trim();
    }

    /// <summary>Композиция: карта создаётся вместе с пациентом и не существует отдельно от него.</summary>
    public MedicalRecord Record { get; }

    public IReadOnlyList<Appointment> Appointments => _appointments;
    public IReadOnlyList<MedicalTest> Tests => _tests;
    public IReadOnlyList<Prescription> Prescriptions => _prescriptions;

    public Patient(int id, string fullName, DateTime birthDate, string phone, string email, string address = "")
        : base(id, fullName, birthDate)
    {
        PhoneNumber = phone;
        Email = email;
        Address = address;
        Record = new MedicalRecord(id, this);
    }

    internal void AddAppointment(Appointment a) => _appointments.Add(a);
    internal void AddTest(MedicalTest t) => _tests.Add(t);
    internal void AddPrescription(Prescription p) => _prescriptions.Add(p);

    /// <summary>Обновляет профиль. Сначала проверяются все поля, затем применяются — частичных изменений не бывает.</summary>
    public void UpdateProfile(string fullName, string phone, string email, string address)
    {
        string n = Guard.NotBlank(fullName, "ФИО");
        string p = Guard.NotBlank(phone, "Телефон");
        string e = Guard.Email(email);
        FullName = n;
        PhoneNumber = p;
        Email = e;
        Address = address;
    }

    public override void DisplayInfo() =>
        ConsoleUi.Card($"Пациент №{PatientId}",
            ("ФИО", FullName),
            ("Дата рождения", BirthText()),
            ("Телефон", PhoneNumber),
            ("Email", Email),
            ("Адрес", Address),
            ("Записей на приём", _appointments.Count.ToString()));
}
