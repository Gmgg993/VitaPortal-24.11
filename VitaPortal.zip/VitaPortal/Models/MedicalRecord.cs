using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>
/// Медицинская карта (задачи 9, 14).
/// Композиция с Patient: конструктор internal, создаётся только самим пациентом
/// и не может существовать без него.
/// </summary>
public class MedicalRecord
{
    private readonly List<string> _history = new();

    public int RecordId { get; }
    public Patient Patient { get; }
    public string Diagnosis { get; private set; } = "не установлен";
    public DateTime CreationDate { get; }

    public IReadOnlyList<string> HistoryEntries => _history;

    public string MedicalHistory =>
        _history.Count == 0 ? "записей нет" : string.Join(Environment.NewLine, _history);

    internal MedicalRecord(int id, Patient patient)
    {
        RecordId = id;
        Patient = patient;
        CreationDate = DateTime.Today;
    }

    public void AddDiagnosis(string diagnosis)
    {
        Diagnosis = Guard.NotBlank(diagnosis, "Диагноз");
        _history.Add($"[{DateTime.Now:dd.MM.yyyy}] Установлен диагноз: {Diagnosis}");
    }

    public void UpdateHistory(string note)
    {
        string text = Guard.NotBlank(note, "Запись в истории болезни");
        _history.Add($"[{DateTime.Now:dd.MM.yyyy}] {text}");
    }

    public void DisplayRecord()
    {
        ConsoleUi.Card($"Медицинская карта №{RecordId}",
            ("Пациент", Patient.FullName),
            ("Создана", CreationDate.ToString("dd.MM.yyyy")),
            ("Диагноз", Diagnosis));
        ConsoleUi.Line("История болезни:");
        if (_history.Count == 0) ConsoleUi.Info("записей нет");
        foreach (var h in _history) ConsoleUi.Line("  " + h);
    }
}
