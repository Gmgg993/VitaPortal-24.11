using VitaPortal.Models;

namespace VitaPortal.Services;

/// <summary>Демонстрационные данные, чтобы портал не был пустым при первом запуске.</summary>
public static class DemoData
{
    /// <summary>Ближайший рабочий день через n дней (воскресенье пропускается).</summary>
    public static DateTime Workday(int daysAhead)
    {
        var d = DateTime.Today.AddDays(daysAhead);
        while (d.DayOfWeek == DayOfWeek.Sunday) d = d.AddDays(1);
        return d;
    }

    public static void Seed(MedicalPortal portal)
    {
        // отделения
        var therapy = portal.AddDepartment("Терапия", 2, "+7 7172 55-01-02");
        var cardio = portal.AddDepartment("Кардиология", 3, "+7 7172 55-01-03");
        var neuro = portal.AddDepartment("Неврология", 3, "+7 7172 55-01-04");
        var pediatrics = portal.AddDepartment("Педиатрия", 1, "+7 7172 55-01-05");

        // врачи
        var akhmetov = portal.AddDoctor("Ахметов Нурлан Серикович", new DateTime(1979, 4, 12), "Терапевт", 18, 201, 350000m);
        var kim = portal.AddDoctor("Ким Елена Викторовна", new DateTime(1985, 9, 3), "Кардиолог", 12, 305, 420000m);
        var sergeeva = portal.AddDoctor("Сергеева Ольга Ивановна", new DateTime(1990, 1, 25), "Невролог", 8, 312, 400000m);
        var bekov = portal.AddDoctor("Беков Данияр Маратович", new DateTime(1982, 6, 17), "Педиатр", 14, 105, 380000m);

        therapy.AddDoctor(akhmetov); therapy.SetHeadDoctor(akhmetov);
        cardio.AddDoctor(kim); cardio.SetHeadDoctor(kim);
        neuro.AddDoctor(sergeeva); neuro.SetHeadDoctor(sergeeva);
        pediatrics.AddDoctor(bekov); pediatrics.SetHeadDoctor(bekov);

        // пациенты
        portal.AddPatient("Жумабаева Айгерим Ерлановна", new DateTime(1995, 3, 14), "+7 701 123-45-67", "aigerim@mail.kz", "Астана, ул. Кенесары, 40");
        portal.AddPatient("Петров Сергей Александрович", new DateTime(1988, 11, 2), "+7 707 222-33-44", "petrov@mail.ru", "Астана, пр. Туран, 12");
        portal.AddPatient("Омарова Динара Талгатовна", new DateTime(2001, 7, 21), "+7 747 555-66-77", "dinara.o@mail.kz");
        portal.AddPatient("Соколов Андрей Павлович", new DateTime(1972, 12, 30), "+7 705 888-99-00", "sokolov@mail.ru", "Астана, ул. Достык, 5");
        portal.AddPatient("Нурланова Мадина Бауыржановна", new DateTime(2015, 5, 9), "+7 771 100-20-30", "madina.mom@mail.kz");

        // услуги
        portal.AddService("Приём терапевта", "Первичный осмотр и консультация", 8000m, 30);
        portal.AddService("Консультация кардиолога", "Осмотр, оценка жалоб, рекомендации", 12000m, 40);
        portal.AddService("ЭКГ", "Электрокардиограмма с расшифровкой", 5000m, 20);
        portal.AddService("Общий анализ крови", "Забор крови и лабораторное исследование", 3500m, 15);
        portal.AddService("Консультация невролога", "Осмотр и назначение обследований", 11000m, 40);
        portal.AddService("УЗИ брюшной полости", "Ультразвуковое исследование", 9500m, 30);

        // приёмы
        portal.BookAppointment(1, 1, Workday(1), new TimeSpan(9, 30, 0), 1);
        portal.BookAppointment(2, 2, Workday(1), new TimeSpan(10, 0, 0), 2);
        portal.BookAppointment(3, 3, Workday(2), new TimeSpan(11, 0, 0), 5);
        portal.BookAppointment(4, 1, Workday(2), new TimeSpan(14, 0, 0), 1);
        portal.BookAppointment(5, 4, Workday(3), new TimeSpan(12, 30, 0));
        portal.ConfirmAppointment(1);
        portal.CompleteAppointment(1);
        portal.ConfirmAppointment(2);
        portal.CancelAppointment(5);

        // медицинские карты
        var p1 = portal.FindPatient(1)!;
        p1.Record.AddDiagnosis("ОРВИ, лёгкое течение");
        p1.Record.UpdateHistory("Жалобы на кашель, температура 37,5. Назначено лечение.");
        portal.FindPatient(4)!.Record.UpdateHistory("Плановый осмотр, жалоб нет.");

        // анализы и назначения
        portal.AddTest(1, "Общий анализ крови", DateTime.Today.AddDays(-3), "Гемоглобин 128 г/л, лейкоциты 6,2 — в норме");
        portal.AddTest(4, "ЭКГ", DateTime.Today.AddDays(-1));
        portal.CreatePrescription(1, 1, "Ибупрофен", "200 мг, 3 раза в день после еды", 5);

        // оплаты
        portal.PayForService(1, 1);
        portal.PayForService(2, 2);
        portal.PayForService(4, 3);

        // заявления (логика прежнего проекта)
        var r1 = portal.AddRequest(1, RequestType.SickLeave, "ОРВИ, температура 37,8. Нужен больничный на 5 дней.");
        r1.ChangeStatus(RequestStatus.UnderReview);
        r1.AssignDoctor(akhmetov);
        r1.SetDoctorRecommendation(akhmetov, true, "Показан домашний режим 5 дней.");
        portal.AddRequest(3, RequestType.Certificate, "Справка для бассейна.");
    }
}
