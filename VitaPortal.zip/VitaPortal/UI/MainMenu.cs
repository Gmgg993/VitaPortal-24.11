using VitaPortal.Models;
using VitaPortal.Services;

namespace VitaPortal.UI;

/// <summary>Главное консольное меню портала (задача 25).</summary>
public class MainMenu
{
    public const string AppName = "VITAPORTAL";
    public const string Subtitle = "Медицинский портал · записи, карты, оплата";

    private readonly MedicalPortal _portal;

    public MainMenu(MedicalPortal portal) => _portal = portal;

    public void Run()
    {
        try
        {
            while (true)
            {
                ConsoleUi.Clear();
                Draw();
                int choice = ConsoleUi.AskInt("Выберите действие", 0, 16);
                if (choice == 0) break;

                ConsoleUi.Clear();
                try
                {
                    Execute(choice);
                }
                catch (ArgumentException ex)
                {
                    ConsoleUi.Error(ex.Message);
                }
                catch (InvalidOperationException ex)
                {
                    ConsoleUi.Error(ex.Message);
                }
                ConsoleUi.Pause();
            }
        }
        catch (EndOfStreamException)
        {
            // ввод закончился (например, окно закрыто) — выходим спокойно
        }

        Console.WriteLine();
        ConsoleUi.Success("Работа завершена. Берегите здоровье!");
    }

    private void Draw()
    {
        Console.WriteLine();
        ConsoleUi.Banner(AppName, Subtitle);

        ConsoleUi.Group("Пациенты и врачи");
        ConsoleUi.MenuItem("1", "Добавить пациента");
        ConsoleUi.MenuItem("2", "Добавить врача");
        ConsoleUi.MenuItem("3", "Показать всех пациентов");
        ConsoleUi.MenuItem("4", "Показать всех врачей");

        ConsoleUi.Group("Приёмы");
        ConsoleUi.MenuItem("5", "Записать пациента на приём");
        ConsoleUi.MenuItem("6", "Отменить запись");
        ConsoleUi.MenuItem("7", "Показать расписание врача");

        ConsoleUi.Group("Лечение");
        ConsoleUi.MenuItem("8", "Добавить медицинский анализ");
        ConsoleUi.MenuItem("9", "Создать медицинское назначение");

        ConsoleUi.Group("Оплата, поиск, отчёты");
        ConsoleUi.MenuItem("10", "Оплатить услугу");
        ConsoleUi.MenuItem("11", "Поиск пациента");
        ConsoleUi.MenuItem("12", "Статистика портала");

        ConsoleUi.Group("Дополнительно");
        ConsoleUi.MenuItem("13", "Подтвердить / завершить приём");
        ConsoleUi.MenuItem("14", "Медицинская карта пациента");
        ConsoleUi.MenuItem("15", "Отделения и услуги");
        ConsoleUi.MenuItem("16", "Заявления на больничный и справки");

        Console.WriteLine();
        ConsoleUi.MenuItem("0", "Выход");
        Console.WriteLine();
    }

    private void Execute(int choice)
    {
        switch (choice)
        {
            case 1: AddPatient(); break;
            case 2: AddDoctor(); break;
            case 3: ShowPatients(); break;
            case 4: ShowDoctors(); break;
            case 5: BookAppointment(); break;
            case 6: CancelAppointment(); break;
            case 7: ShowSchedule(); break;
            case 8: AddTest(); break;
            case 9: CreatePrescription(); break;
            case 10: Pay(); break;
            case 11: SearchPatient(); break;
            case 12: ShowStatistics(); break;
            case 13: ConfirmOrComplete(); break;
            case 14: MedicalRecordMenu(); break;
            case 15: DepartmentsAndServices(); break;
            case 16: Requests(); break;
        }
    }

    // ------------------------------------------------------------------
    //  вспомогательное
    // ------------------------------------------------------------------

    private static string AskValid(string label, Func<string, string> validate)
    {
        while (true)
        {
            var s = ConsoleUi.Ask(label, required: false);
            try { return validate(s); }
            catch (ArgumentException ex) { ConsoleUi.Error(ex.Message); }
        }
    }

    private static DateTime AskBirthDate()
    {
        while (true)
        {
            var d = ConsoleUi.AskDate("Дата рождения");
            if (d > DateTime.Today) { ConsoleUi.Error("Дата рождения не может быть в будущем."); continue; }
            if (d.Year < 1900) { ConsoleUi.Error("Дата рождения указана неверно."); continue; }
            return d;
        }
    }

    private Patient? AskPatient()
    {
        int id = ConsoleUi.AskInt("Номер пациента", 1);
        var p = _portal.FindPatient(id);
        if (p == null) ConsoleUi.Error($"Пациент с номером {id} не найден.");
        return p;
    }

    private Doctor? AskDoctor()
    {
        int id = ConsoleUi.AskInt("Номер врача", 1);
        var d = _portal.FindDoctor(id);
        if (d == null) ConsoleUi.Error($"Врач с номером {id} не найден.");
        return d;
    }

    private static string[] PatientRow(Patient p) => new[]
    {
        p.PatientId.ToString(), p.FullName, p.BirthDate.ToString("dd.MM.yyyy"),
        p.GetAge().ToString(), p.PhoneNumber, p.Email
    };

    private void PatientsTable(IEnumerable<Patient> patients) =>
        ConsoleUi.Table(new[] { "ID", "ФИО", "Родился", "Лет", "Телефон", "Email" }, patients.Select(PatientRow));

    private void DoctorsTable(IEnumerable<Doctor> doctors) =>
        ConsoleUi.Table(new[] { "ID", "ФИО", "Специализация", "Стаж", "Каб.", "Отделение" },
            doctors.Select(d => new[]
            {
                d.DoctorId.ToString(), d.FullName, d.Specialization, d.Experience + " л.",
                d.CabinetNumber.ToString(), d.Department?.DepartmentName ?? "—"
            }));

    private void ServicesTable() =>
        ConsoleUi.Table(new[] { "ID", "Услуга", "Цена", "Мин." },
            _portal.Services.Select(s => new[]
            {
                s.ServiceId.ToString(), s.ServiceName, ConsoleUi.Money(s.Price), ((int)s.Duration.TotalMinutes).ToString()
            }));

    private void AppointmentsTable(IEnumerable<Appointment> list) =>
        ConsoleUi.Table(new[] { "№", "Дата", "Время", "Пациент", "Врач", "Статус" },
            list.Select(a => new[]
            {
                a.AppointmentId.ToString(), a.AppointmentDate.ToString("dd.MM.yyyy"), a.AppointmentTime.ToString(@"hh\:mm"),
                a.Patient.FullName, a.Doctor.FullName, a.Status.Ru()
            }));

    private static void Report(OpResult r)
    {
        if (r.Ok) ConsoleUi.Success(r.Message);
        else ConsoleUi.Error(r.Message);
    }

    // ------------------------------------------------------------------
    //  1–4. пациенты и врачи
    // ------------------------------------------------------------------

    private void AddPatient()
    {
        ConsoleUi.Title("Новый пациент");
        string name = AskValid("ФИО", s => Guard.NotBlank(s, "ФИО"));
        var birth = AskBirthDate();
        string phone = AskValid("Телефон", s => Guard.NotBlank(s, "Телефон"));
        string email = AskValid("Email", Guard.Email);
        string address = ConsoleUi.Ask("Адрес (Enter — пропустить)", required: false);

        var p = _portal.AddPatient(name, birth, phone, email, address);
        Console.WriteLine();
        ConsoleUi.Success($"Пациент добавлен, номер {p.PatientId}.");
        p.DisplayInfo();
    }

    private void AddDoctor()
    {
        ConsoleUi.Title("Новый врач");
        string name = AskValid("ФИО", s => Guard.NotBlank(s, "ФИО"));
        var birth = AskBirthDate();
        string spec = AskValid("Специализация", s => Guard.NotBlank(s, "Специализация"));
        int exp = ConsoleUi.AskInt("Стаж, лет", 0, 60);
        int cab = ConsoleUi.AskInt("Номер кабинета", 1, 9999);
        decimal salary = ConsoleUi.AskDecimal("Оклад, ₸", 0);

        var d = _portal.AddDoctor(name, birth, spec, exp, cab, salary);

        if (_portal.Departments.Count > 0)
        {
            Console.WriteLine();
            DepartmentsTable();
            int depId = ConsoleUi.AskInt("Номер отделения (0 — без отделения)", 0);
            if (depId > 0)
            {
                var dep = _portal.FindDepartment(depId);
                if (dep == null) ConsoleUi.Warning("Отделение не найдено — врач добавлен без отделения.");
                else dep.AddDoctor(d);
            }
        }

        Console.WriteLine();
        ConsoleUi.Success($"Врач добавлен, номер {d.DoctorId}.");
        d.DisplayInfo();
    }

    private void ShowPatients()
    {
        ConsoleUi.Title("Все пациенты");
        PatientsTable(_portal.Patients);
        if (_portal.Patients.Count == 0) return;

        Console.WriteLine();
        var s = ConsoleUi.Ask("Номер пациента для подробностей (Enter — пропустить)", required: false);
        if (int.TryParse(s, out int id))
        {
            var p = _portal.FindPatient(id);
            if (p == null) ConsoleUi.Error($"Пациент с номером {id} не найден.");
            else { Console.WriteLine(); p.DisplayInfo(); }
        }
    }

    private void ShowDoctors()
    {
        ConsoleUi.Title("Все врачи");
        DoctorsTable(_portal.Doctors);
        if (_portal.Doctors.Count == 0) return;

        Console.WriteLine();
        var s = ConsoleUi.Ask("Номер врача для подробностей (Enter — пропустить)", required: false);
        if (int.TryParse(s, out int id))
        {
            var d = _portal.FindDoctor(id);
            if (d == null) ConsoleUi.Error($"Врач с номером {id} не найден.");
            else { Console.WriteLine(); d.DisplayInfo(); }
        }
    }

    // ------------------------------------------------------------------
    //  5–7. приёмы
    // ------------------------------------------------------------------

    private void BookAppointment()
    {
        ConsoleUi.Title("Запись на приём");
        if (_portal.Patients.Count == 0 || _portal.Doctors.Count == 0)
        {
            ConsoleUi.Warning("Сначала добавьте хотя бы одного пациента и одного врача.");
            return;
        }

        PatientsTable(_portal.Patients);
        var patient = AskPatient();
        if (patient == null) return;

        Console.WriteLine();
        DoctorsTable(_portal.Doctors);
        var doctor = AskDoctor();
        if (doctor == null) return;

        Console.WriteLine();
        var date = ConsoleUi.AskDate("Дата приёма");
        var time = ConsoleUi.AskTime("Время приёма");

        Console.WriteLine();
        ServicesTable();
        int serviceId = ConsoleUi.AskInt("Номер услуги (0 — обычная консультация)", 0);

        var result = _portal.BookAppointment(patient.PatientId, doctor.DoctorId, date, time,
            serviceId == 0 ? null : serviceId);

        Console.WriteLine();
        Report(result);
        if (result.Ok) _portal.Appointments.Last().DisplayAppointment();
    }

    private void CancelAppointment()
    {
        ConsoleUi.Title("Отмена записи");
        var active = _portal.Appointments
            .Where(a => a.Status is AppointmentStatus.Scheduled or AppointmentStatus.Confirmed)
            .ToList();
        AppointmentsTable(active);
        if (active.Count == 0) return;

        Console.WriteLine();
        int id = ConsoleUi.AskInt("Номер записи", 1);
        var a = _portal.FindAppointment(id);
        if (a != null && !ConsoleUi.Confirm($"Отменить запись №{id} ({a.Patient.FullName})?"))
        {
            ConsoleUi.Info("Отмена не выполнена.");
            return;
        }
        Report(_portal.CancelAppointment(id));
    }

    private void ShowSchedule()
    {
        ConsoleUi.Title("Расписание врача");
        DoctorsTable(_portal.Doctors);
        var doctor = AskDoctor();
        if (doctor == null) return;

        var text = ConsoleUi.Ask("Дата дд.мм.гггг (Enter — все дни)", required: false);
        DateTime? day = null;
        if (text.Length > 0)
        {
            if (!ConsoleUi.TryParseDate(text, out var parsed))
            {
                ConsoleUi.Error("Неверная дата. Пример: 25.11.2026");
                return;
            }
            day = parsed;
        }

        Console.WriteLine();
        ConsoleUi.Title($"{doctor.FullName} — {doctor.Specialization}, каб. {doctor.CabinetNumber}");
        AppointmentsTable(_portal.GetDoctorSchedule(doctor, day));

        if (day != null)
        {
            Console.WriteLine();
            if (day.Value.DayOfWeek == DayOfWeek.Sunday)
            {
                ConsoleUi.Info("В воскресенье приёма нет.");
                return;
            }

            var free = new List<string>();
            for (var t = Doctor.WorkDayStart; t < Doctor.WorkDayEnd; t += TimeSpan.FromMinutes(30))
            {
                if (doctor.IsDoctorAvailable(day.Value + t)) free.Add(t.ToString(@"hh\:mm"));
            }
            ConsoleUi.Line("Свободное время: " + (free.Count == 0 ? "нет" : string.Join("  ", free)));
        }
    }

    private void ConfirmOrComplete()
    {
        ConsoleUi.Title("Подтвердить / завершить приём");
        var active = _portal.Appointments
            .Where(a => a.Status is AppointmentStatus.Scheduled or AppointmentStatus.Confirmed)
            .ToList();
        AppointmentsTable(active);
        if (active.Count == 0) return;

        Console.WriteLine();
        ConsoleUi.MenuItem("1", "Подтвердить запись");
        ConsoleUi.MenuItem("2", "Завершить приём");
        int action = ConsoleUi.AskInt("Действие", 1, 2);
        int id = ConsoleUi.AskInt("Номер записи", 1);
        Report(action == 1 ? _portal.ConfirmAppointment(id) : _portal.CompleteAppointment(id));
    }

    // ------------------------------------------------------------------
    //  8–9. анализы и назначения
    // ------------------------------------------------------------------

    private void AddTest()
    {
        ConsoleUi.Title("Медицинский анализ");
        PatientsTable(_portal.Patients);
        var patient = AskPatient();
        if (patient == null) return;

        string name = AskValid("Название анализа", s => Guard.NotBlank(s, "Название анализа"));
        var date = ConsoleUi.AskDate("Дата сдачи");
        string result = ConsoleUi.Ask("Результат (Enter — внести позже)", required: false);

        var test = _portal.AddTest(patient.PatientId, name, date, result);
        Console.WriteLine();
        ConsoleUi.Success($"Анализ №{test.TestId} добавлен.");
        test.DisplayResult();

        if (!test.HasResult) return;
        Console.WriteLine();
        if (ConsoleUi.Confirm("Изменить результат?"))
        {
            test.UpdateResult(AskValid("Новый результат", s => Guard.NotBlank(s, "Результат")));
            ConsoleUi.Success("Результат обновлён.");
        }
    }

    private void CreatePrescription()
    {
        ConsoleUi.Title("Медицинское назначение");
        PatientsTable(_portal.Patients);
        var patient = AskPatient();
        if (patient == null) return;
        Console.WriteLine();
        DoctorsTable(_portal.Doctors);
        var doctor = AskDoctor();
        if (doctor == null) return;

        string med = AskValid("Препарат", s => Guard.NotBlank(s, "Препарат"));
        string dosage = AskValid("Дозировка (например: 1 таблетка 2 раза в день)", s => Guard.NotBlank(s, "Дозировка"));
        int days = ConsoleUi.AskInt("Курс, дней", 1, 365);

        var p = _portal.CreatePrescription(patient.PatientId, doctor.DoctorId, med, dosage, days);
        Console.WriteLine();
        ConsoleUi.Success($"Назначение №{p.PrescriptionId} оформлено.");
        p.DisplayPrescription();
    }

    // ------------------------------------------------------------------
    //  10. оплата
    // ------------------------------------------------------------------

    private void Pay()
    {
        ConsoleUi.Title("Оплата услуг");
        ConsoleUi.MenuItem("1", "Оплатить услугу");
        ConsoleUi.MenuItem("2", "Вернуть платёж");
        ConsoleUi.MenuItem("3", "Список платежей");
        int action = ConsoleUi.AskInt("Действие", 1, 3);
        Console.WriteLine();

        if (action == 1)
        {
            PatientsTable(_portal.Patients);
            var patient = AskPatient();
            if (patient == null) return;
            Console.WriteLine();
            ServicesTable();
            int serviceId = ConsoleUi.AskInt("Номер услуги", 1);
            int qty = ConsoleUi.AskInt("Количество", 1, 100);
            int discount = ConsoleUi.AskInt("Скидка, % (0 — без скидки)", 0, 100);

            var result = _portal.PayForService(patient.PatientId, serviceId, qty, discount);
            Console.WriteLine();
            Report(result);
            if (result.Ok) _portal.Payments.Last().DisplayPayment();
        }
        else if (action == 2)
        {
            PaymentsTable();
            if (_portal.Payments.Count == 0) return;
            Console.WriteLine();
            Report(_portal.RefundPayment(ConsoleUi.AskInt("Номер платежа", 1)));
        }
        else
        {
            PaymentsTable();
        }
    }

    private void PaymentsTable() =>
        ConsoleUi.Table(new[] { "№", "Пациент", "Услуга", "Сумма", "Статус" },
            _portal.Payments.Select(p => new[]
            {
                p.PaymentId.ToString(), p.Patient.FullName, p.Service?.ServiceName ?? "—",
                ConsoleUi.Money(p.Amount), p.PaymentStatus.Ru()
            }));

    // ------------------------------------------------------------------
    //  11. поиск
    // ------------------------------------------------------------------

    private void SearchPatient()
    {
        ConsoleUi.Title("Поиск пациента");
        ConsoleUi.MenuItem("1", "По номеру");
        ConsoleUi.MenuItem("2", "По ФИО (можно часть)");
        ConsoleUi.MenuItem("3", "По номеру телефона (можно часть)");
        int mode = ConsoleUi.AskInt("Способ поиска", 1, 3);

        List<Patient> found;
        if (mode == 1)
        {
            var p = _portal.FindPatientById(ConsoleUi.AskInt("Номер пациента", 1));
            found = p == null ? new List<Patient>() : new List<Patient> { p };
        }
        else if (mode == 2)
        {
            found = _portal.FindPatientsByName(ConsoleUi.Ask("ФИО или его часть"));
        }
        else
        {
            found = _portal.FindPatientsByPhone(ConsoleUi.Ask("Телефон или его часть"));
        }

        Console.WriteLine();
        if (found.Count == 0)
        {
            ConsoleUi.Warning("Пациент не найден. Проверьте данные и попробуйте ещё раз.");
            return;
        }

        PatientsTable(found);
        if (found.Count == 1)
        {
            Console.WriteLine();
            found[0].DisplayInfo();
        }
    }

    // ------------------------------------------------------------------
    //  12. статистика
    // ------------------------------------------------------------------

    private void ShowStatistics()
    {
        ConsoleUi.Title("Статистика портала");
        var s = _portal.GetStatistics();
        ConsoleUi.Card("Сводка",
            ("Пациентов", s.Patients.ToString()),
            ("Врачей", s.Doctors.ToString()),
            ("Отделений", s.Departments.ToString()),
            ("Записей на приём", s.Appointments.ToString()),
            ("Завершённых приёмов", s.Completed.ToString()),
            ("Отменённых записей", s.Cancelled.ToString()),
            ("Оплаченных платежей", s.PaidPayments.ToString()),
            ("Сумма оплаченных услуг", ConsoleUi.Money(s.PaidTotal)));
    }

    // ------------------------------------------------------------------
    //  14. медицинская карта
    // ------------------------------------------------------------------

    private void MedicalRecordMenu()
    {
        ConsoleUi.Title("Медицинская карта");
        PatientsTable(_portal.Patients);
        var patient = AskPatient();
        if (patient == null) return;

        Console.WriteLine();
        ConsoleUi.MenuItem("1", "Показать карту");
        ConsoleUi.MenuItem("2", "Установить диагноз");
        ConsoleUi.MenuItem("3", "Добавить запись в историю болезни");
        ConsoleUi.MenuItem("4", "Анализы и назначения пациента");
        int action = ConsoleUi.AskInt("Действие", 1, 4);
        Console.WriteLine();

        switch (action)
        {
            case 1:
                patient.Record.DisplayRecord();
                break;
            case 2:
                patient.Record.AddDiagnosis(AskValid("Диагноз", s => Guard.NotBlank(s, "Диагноз")));
                ConsoleUi.Success("Диагноз сохранён.");
                break;
            case 3:
                patient.Record.UpdateHistory(AskValid("Запись", s => Guard.NotBlank(s, "Запись")));
                ConsoleUi.Success("Запись добавлена в историю болезни.");
                break;
            default:
                if (patient.Tests.Count == 0) ConsoleUi.Info("Анализов нет.");
                foreach (var t in patient.Tests) t.DisplayResult();
                if (patient.Prescriptions.Count == 0) ConsoleUi.Info("Назначений нет.");
                foreach (var p in patient.Prescriptions) p.DisplayPrescription();
                break;
        }
    }

    // ------------------------------------------------------------------
    //  15. отделения и услуги
    // ------------------------------------------------------------------

    private void DepartmentsTable() =>
        ConsoleUi.Table(new[] { "ID", "Отделение", "Этаж", "Телефон", "Заведующий", "Врачей" },
            _portal.Departments.Select(d => new[]
            {
                d.DepartmentId.ToString(), d.DepartmentName, d.Floor.ToString(), d.PhoneNumber,
                d.HeadDoctor?.FullName ?? "—", d.Doctors.Count.ToString()
            }));

    private Department? AskDepartment()
    {
        int id = ConsoleUi.AskInt("Номер отделения", 1);
        var d = _portal.FindDepartment(id);
        if (d == null) ConsoleUi.Error($"Отделение с номером {id} не найдено.");
        return d;
    }

    private void DepartmentsAndServices()
    {
        ConsoleUi.Title("Отделения и услуги");
        ConsoleUi.MenuItem("1", "Список отделений");
        ConsoleUi.MenuItem("2", "Врачи отделения");
        ConsoleUi.MenuItem("3", "Добавить врача в отделение");
        ConsoleUi.MenuItem("4", "Убрать врача из отделения");
        ConsoleUi.MenuItem("5", "Назначить заведующего");
        ConsoleUi.MenuItem("6", "Добавить отделение");
        ConsoleUi.MenuItem("7", "Список услуг");
        ConsoleUi.MenuItem("8", "Изменить стоимость услуги");
        ConsoleUi.MenuItem("9", "Добавить услугу");
        int action = ConsoleUi.AskInt("Действие", 1, 9);
        Console.WriteLine();

        switch (action)
        {
            case 1:
                DepartmentsTable();
                break;
            case 2:
                {
                    DepartmentsTable();
                    var dep = AskDepartment();
                    dep?.DisplayDoctors();
                    break;
                }
            case 3:
                {
                    DepartmentsTable();
                    var dep = AskDepartment();
                    if (dep == null) break;
                    DoctorsTable(_portal.Doctors);
                    var doc = AskDoctor();
                    if (doc == null) break;
                    if (dep.AddDoctor(doc))
                        ConsoleUi.Success($"{doc.FullName} теперь работает в отделении «{dep.DepartmentName}».");
                    else
                        ConsoleUi.Error($"Врач уже закреплён за отделением «{doc.Department?.DepartmentName}». Сначала уберите его оттуда.");
                    break;
                }
            case 4:
                {
                    DepartmentsTable();
                    var dep = AskDepartment();
                    if (dep == null) break;
                    dep.DisplayDoctors();
                    var doc = AskDoctor();
                    if (doc == null) break;
                    if (dep.RemoveDoctor(doc))
                        ConsoleUi.Success($"{doc.FullName} убран из отделения. Сам врач остаётся в системе.");
                    else
                        ConsoleUi.Error("Этот врач не работает в выбранном отделении.");
                    break;
                }
            case 5:
                {
                    DepartmentsTable();
                    var dep = AskDepartment();
                    if (dep == null) break;
                    dep.DisplayDoctors();
                    var doc = AskDoctor();
                    if (doc == null) break;
                    if (dep.SetHeadDoctor(doc))
                        ConsoleUi.Success($"{doc.FullName} назначен заведующим отделением «{dep.DepartmentName}».");
                    else
                        ConsoleUi.Error("Заведующим можно назначить только врача этого отделения.");
                    break;
                }
            case 6:
                {
                    string name = AskValid("Название отделения", s => Guard.NotBlank(s, "Название отделения"));
                    int floor = ConsoleUi.AskInt("Этаж", -2, 50);
                    string phone = AskValid("Телефон", s => Guard.NotBlank(s, "Телефон"));
                    var dep = _portal.AddDepartment(name, floor, phone);
                    ConsoleUi.Success($"Отделение «{dep.DepartmentName}» добавлено, номер {dep.DepartmentId}.");
                    break;
                }
            case 7:
                ServicesTable();
                break;
            case 8:
                {
                    ServicesTable();
                    int id = ConsoleUi.AskInt("Номер услуги", 1);
                    var svc = _portal.FindService(id);
                    if (svc == null) { ConsoleUi.Error($"Услуга с номером {id} не найдена."); break; }
                    svc.UpdatePrice(ConsoleUi.AskDecimal("Новая стоимость, ₸", 0));
                    ConsoleUi.Success("Стоимость обновлена.");
                    svc.DisplayService();
                    break;
                }
            default:
                {
                    string name = AskValid("Название услуги", s => Guard.NotBlank(s, "Название услуги"));
                    string descr = ConsoleUi.Ask("Описание (Enter — пропустить)", required: false);
                    decimal price = ConsoleUi.AskDecimal("Стоимость, ₸", 0);
                    int minutes = ConsoleUi.AskInt("Длительность, минут", 1, 600);
                    var svc = _portal.AddService(name, descr, price, minutes);
                    ConsoleUi.Success($"Услуга добавлена, номер {svc.ServiceId}.");
                    svc.DisplayService();
                    break;
                }
        }
    }

    // ------------------------------------------------------------------
    //  16. заявления на больничный и справки
    // ------------------------------------------------------------------

    private void RequestsTable() =>
        ConsoleUi.Table(new[] { "№", "Пациент", "Тип", "Статус", "Врач" },
            _portal.Requests.Select(r => new[]
            {
                r.RequestId.ToString(), r.Patient.FullName, r.Type.Ru(), r.Status.Ru(),
                r.AssignedDoctor?.FullName ?? "—"
            }));

    private SickLeaveRequest? AskRequest()
    {
        int id = ConsoleUi.AskInt("Номер заявления", 1);
        var r = _portal.FindRequest(id);
        if (r == null) ConsoleUi.Error($"Заявление №{id} не найдено.");
        return r;
    }

    private void Requests()
    {
        ConsoleUi.Title("Заявления на больничный и справки");
        ConsoleUi.MenuItem("1", "Подать заявление (от лица пациента)");
        ConsoleUi.MenuItem("2", "Список заявлений");
        ConsoleUi.MenuItem("3", "Назначить врача");
        ConsoleUi.MenuItem("4", "Заключение врача");
        ConsoleUi.MenuItem("5", "Изменить статус (решение администратора)");
        ConsoleUi.MenuItem("6", "Карточка заявления");
        int action = ConsoleUi.AskInt("Действие", 1, 6);
        Console.WriteLine();

        switch (action)
        {
            case 1:
                {
                    PatientsTable(_portal.Patients);
                    var patient = AskPatient();
                    if (patient == null) break;
                    ConsoleUi.MenuItem("1", "Больничный");
                    ConsoleUi.MenuItem("2", "Справка");
                    var type = ConsoleUi.AskInt("Тип", 1, 2) == 1 ? RequestType.SickLeave : RequestType.Certificate;
                    string reason = AskValid("Причина обращения", s => Guard.NotBlank(s, "Причина обращения"));
                    var r = _portal.AddRequest(patient.PatientId, type, reason);
                    ConsoleUi.Success($"Заявление №{r.RequestId} подано. Статус: «{r.Status.Ru()}».");
                    ConsoleUi.Info("Пациент не может выдать себе больничный — решение принимает администратор.");
                    break;
                }
            case 2:
                RequestsTable();
                break;
            case 3:
                {
                    RequestsTable();
                    var r = AskRequest();
                    if (r == null) break;
                    DoctorsTable(_portal.Doctors);
                    var doc = AskDoctor();
                    if (doc == null) break;
                    r.AssignDoctor(doc);
                    ConsoleUi.Success($"Врач {doc.FullName} назначен.");
                    break;
                }
            case 4:
                {
                    RequestsTable();
                    var r = AskRequest();
                    if (r == null) break;
                    var doc = AskDoctor();
                    if (doc == null) break;
                    bool approve = ConsoleUi.Confirm("Рекомендуете одобрить?");
                    string comment = AskValid("Заключение", s => Guard.NotBlank(s, "Заключение врача"));
                    r.SetDoctorRecommendation(doc, approve, comment);
                    ConsoleUi.Success("Заключение сохранено. Окончательное решение — за администратором.");
                    break;
                }
            case 5:
                {
                    RequestsTable();
                    var r = AskRequest();
                    if (r == null) break;
                    ConsoleUi.Info($"Сейчас: «{r.Status.Ru()}». Возможные переходы:");
                    var options = Enum.GetValues<RequestStatus>().Where(r.CanGoTo).ToList();
                    if (options.Count == 0) { ConsoleUi.Warning("Из этого статуса переходов нет."); break; }
                    for (int i = 0; i < options.Count; i++) ConsoleUi.MenuItem((i + 1).ToString(), options[i].Ru());
                    var next = options[ConsoleUi.AskInt("Новый статус", 1, options.Count) - 1];

                    string? reason = null, doc = null;
                    if (next == RequestStatus.Rejected) reason = ConsoleUi.Ask("Причина отказа");
                    if (next == RequestStatus.Completed) doc = ConsoleUi.Ask("Номер готового документа");
                    r.ChangeStatus(next, reason, doc);
                    ConsoleUi.Success($"Статус изменён: «{r.Status.Ru()}».");
                    break;
                }
            default:
                {
                    RequestsTable();
                    AskRequest()?.Display();
                    break;
                }
        }
    }
}
