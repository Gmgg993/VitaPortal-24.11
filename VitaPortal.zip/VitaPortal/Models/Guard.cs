namespace VitaPortal.Models;

/// <summary>Проверки входных данных (инкапсуляция, задача 19).</summary>
public static class Guard
{
    public static string NotBlank(string? value, string field)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException($"Поле «{field}» не может быть пустым.");
        return value.Trim();
    }

    public static string Email(string? value)
    {
        var email = NotBlank(value, "Email");
        int at = email.IndexOf('@');
        if (at < 1 || email.IndexOf('.', at) < at + 2 || email.EndsWith('.'))
            throw new ArgumentException("Email указан неверно (пример: name@mail.kz).");
        return email;
    }

    public static decimal NotNegative(decimal value, string field)
    {
        if (value < 0)
            throw new ArgumentException($"«{field}» не может быть меньше нуля.");
        return value;
    }

    public static int InRange(int value, int min, int max, string field)
    {
        if (value < min || value > max)
            throw new ArgumentException($"«{field}» должно быть от {min} до {max}.");
        return value;
    }

    public static T NotNull<T>(T? value, string field) where T : class
    {
        return value ?? throw new ArgumentNullException(field, $"«{field}» обязательно.");
    }
}
