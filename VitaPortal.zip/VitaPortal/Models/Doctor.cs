using VitaPortal.UI;

namespace VitaPortal.Models;

/// <summary>Врач (задачи 3, 7, 12, 17, 18). Наследует Person, реализует IPayable.</summary>
public class Doctor : Person, IPayable
{
    /// <summary>Рабочее время: пн–сб, 09:00–18:00.</summary>
    public static readonly TimeSpan WorkDayStart = new(9, 0, 0);
    public static readonly TimeSpan WorkDayEnd = new(18, 0, 0);

    private string _specialization = "";
    private int _experience;
    private int _cabinet;
    private decimal _salary;
    private readonly List<Appointment> _appointments = new();

    public int DoctorId => Id;

    public string Specialization
    {
        get => _specialization;
        set => _specialization = Guard.NotBlank(value, "Специализация");
    }

    /// <summary>Стаж в годах.</summary>
    public int Experience
    {
        get => _experience;
        set => _experience = Guard.InRange(value, 0, 60, "Стаж");
    }

    public int CabinetNumber
    {
        get => _cabinet;
        set => _cabinet = Guard.InRange(value, 1, 9999, "Номер кабинета");
    }

    /// <summary>Базовый оклад.</summary>
    public decimal Salary
    {
        get => _salary;
        set => _salary = Guard.NotNegative(value, "Оклад");
    }

    /// <summary>Агрегация: врач может работать вне отделения (null).</summary>
    public Department? Department { get; internal set; }

    public IReadOnlyList<Appointment> Appointments => _appointments;

    public Doctor(int id, string fullName, DateTime birthDate, string specialization,
                  int experience, int cabinetNumber, decimal salary)
        : base(id, fullName, birthDate)
    {
        Specialization = specialization;
        Experience = experience;
        CabinetNumber = cabinetNumber;
        Salary = salary;
    }

    internal void AddAppointment(Appointment a) => _appointments.Add(a);

    public void UpdateSpecialization(string newSpecialization) => Specialization = newSpecialization;

    /// <summary>Оклад + 2% за каждый год стажа (но не более 25 лет).</summary>
    public decimal CalculateSalary() =>
        Math.Round(Salary * (1 + 0.02m * Math.Min(Experience, 25)), 2);

    public decimal CalculatePayment() => CalculateSalary();

    public static bool IsWorkingTime(DateTime moment) =>
        moment.DayOfWeek != DayOfWeek.Sunday &&
        moment.TimeOfDay >= WorkDayStart &&
        moment.TimeOfDay < WorkDayEnd;

    /// <summary>
    /// Свободен ли врач на указанные дату и время (задача 7):
    /// рабочее время и нет активной записи на тот же момент.
    /// </summary>
    public bool IsDoctorAvailable(DateTime date)
    {
        if (!IsWorkingTime(date)) return false;
        var slot = Trim(date);
        return !_appointments.Any(a => a.Status != AppointmentStatus.Cancelled && a.StartsAt == slot);
    }

    internal static DateTime Trim(DateTime d) => new(d.Year, d.Month, d.Day, d.Hour, d.Minute, 0);

    public override void DisplayInfo() =>
        ConsoleUi.Card($"Врач №{DoctorId}",
            ("ФИО", FullName),
            ("Дата рождения", BirthText()),
            ("Специализация", Specialization),
            ("Стаж", $"{Experience} лет"),
            ("Кабинет", CabinetNumber.ToString()),
            ("Отделение", Department?.DepartmentName ?? "не назначено"),
            ("Оклад", ConsoleUi.Money(Salary)),
            ("К выплате", ConsoleUi.Money(CalculateSalary())));
}
